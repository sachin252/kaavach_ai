# Kaavach AI

Bug bounty and vulnerability disclosure platform. Companies launch programs, researchers submit reports, companies triage and reward valid findings.

Stack: React 18 + Vite + Tailwind (frontend), Node 20 + Express + Socket.IO (API), MongoDB.

The API also serves the built frontend, so the whole product runs as **one web service** with one URL.

---

## Roles

| Role | Can do |
|---|---|
| Researcher (hacker) | Browse programs, submit reports with PDF/DOCX proof, track status, earn bounties, XP, badges and leaderboard rank, publish writeups and marketplace items |
| Company | Launch and pause programs (with scope and reward range), triage reports, download attachments, accept and reward, post jobs, view analytics |
| Admin | Approve or reject companies, manage users and programs, publish knowledge base articles and breach alerts, platform analytics and abuse watchlist |

---

## Deploy to production

You need two things:

1. **MongoDB Atlas** (free M0 is fine to start): create a cluster, a database user, allow network access from `0.0.0.0/0` (or your host's IPs), copy the `mongodb+srv://...` connection string.
2. **A host**. Vercel, Render and Railway are pre-configured.

### Option A: Vercel

The repo is Vercel-ready (`vercel.json` + `api/index.js`). The React app is served from Vercel's CDN and the Express API runs as one serverless function.

1. Create a MongoDB Atlas database (Vercel > Storage > Marketplace > MongoDB Atlas, or cloud.mongodb.com). In Atlas Network Access allow `0.0.0.0/0`, because Vercel functions have no fixed IP.
2. Import the repo in Vercel. Use a project name without underscores (e.g. `kaavach-ai`). Framework preset: Other; leave build settings empty, `vercel.json` sets them.
3. Add environment variables: `MONGO_URI`, `JWT_SECRET` (32+ chars), `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `COMPANY_AUTO_APPROVE=false`, `NODE_ENV=production`.
4. Deploy, then open `/api/health`.

Differences on Vercel: report attachments are limited to 4 MB (Vercel request size limit) and notifications refresh every 30 seconds instead of instantly, because serverless functions cannot hold WebSocket connections. Attachments are stored in MongoDB (GridFS), so no extra storage service is needed.

CLI alternative: `npx vercel --prod` from the repo root after `vercel login`.

### Option B: Render

1. Push this folder to a GitHub repo.
2. On Render: **New > Blueprint**, pick the repo. `render.yaml` creates the service, a health check and a 5 GB disk for report attachments.
3. Fill the prompted variables:
   - `MONGO_URI`: your Atlas string
   - `CLIENT_ORIGIN`: your public URL, e.g. `https://kaavach-ai.onrender.com`
   - `ADMIN_EMAIL`, `ADMIN_PASSWORD` (10+ chars): the first admin is created automatically on first boot
4. Deploy. Open `/api/health`, it should say `"db":"connected"`.
5. Seed the knowledge base once from the Render shell: `npm run seed:kb`
6. Add your custom domain in Render and append it to `CLIENT_ORIGIN`.

### Option C: Railway

New project from the repo. `railway.json` builds the Dockerfile. Add the same variables as above. Add a volume mounted at `/var/data` and set `UPLOAD_DIR=/var/data/uploads`.

### Option D: Any VPS / Docker

```bash
docker build -f docker/Dockerfile -t kaavach-ai .
docker run -d -p 5000:5000 --env-file backend/.env -v kaavach_uploads:/app/backend/uploads kaavach-ai
```

Put Nginx or Caddy in front for HTTPS.

### Option E: Without Docker (any Node 20 host)

```bash
npm run build   # installs both apps and builds the frontend
npm start       # starts the API, which also serves the frontend
```

### Environment variables

| Variable | Required | Notes |
|---|---|---|
| `MONGO_URI` | yes | MongoDB connection string |
| `JWT_SECRET` | yes | 32+ random chars in production (`openssl rand -hex 32`) |
| `CLIENT_ORIGIN` | yes | Comma separated public URLs allowed by CORS and sockets |
| `ADMIN_EMAIL` / `ADMIN_PASSWORD` | first boot | Creates the first admin if none exists |
| `COMPANY_AUTO_APPROVE` | no | `false` (default in render.yaml) means admins approve new companies |
| `UPLOAD_DIR` | no | Put this on a persistent disk in production |
| `JWT_EXPIRE` | no | Default `7d` |
| `PORT` | no | Set by the host |

Frontend variables (`frontend/.env`) are only needed if you host the frontend separately from the API: `VITE_API_URL=https://api.example.com/api` and `VITE_SOCKET_URL=https://api.example.com`.

---

## Local development

```bash
# 1. API
cd backend
cp .env.example .env        # set MONGO_URI, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
npm install
npm run dev                 # http://localhost:5000

# 2. Web app (new terminal)
cd frontend
npm install
npm run dev                 # http://localhost:3000, proxies /api and sockets to :5000
```

Useful scripts (in `backend/`):

- `npm run seed` creates the admin from `ADMIN_EMAIL` / `ADMIN_PASSWORD`
- `npm run seed:kb` adds the starter knowledge base articles
- `npm run recalc:xp` rebuilds XP, points and badges from accepted reports

---

## Security model

- Passwords hashed with bcrypt (cost 12); password hashes and reset tokens never leave the API
- JWT auth; Socket.IO connections authenticate with the same token and only join the user's own room
- Report attachments are stored in MongoDB GridFS (never in a public folder) and served only through `GET /api/reports/:id/file` to the researcher, the program owner or an admin
- Report detail is restricted the same way (no cross-tenant access)
- Upload checks on extension, MIME type and file signature, 10 MB limit (4 MB on Vercel)
- Helmet security headers with a strict CSP, HSTS, CORS allow-list
- Rate limits: 20 login/register attempts per 15 min per IP, 600 API calls per 15 min per IP
- NoSQL operator injection stripped from all inputs; mass-assignment blocked with field allow-lists
- XP and points are awarded once per report and reversed if an accepted report is later rejected
- Programs that already have reports are closed instead of deleted, preserving the audit trail

## API overview

| Area | Endpoints |
|---|---|
| Auth | `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`, `PUT /api/auth/profile`, `PUT /api/auth/password` |
| Programs | `GET /api/programs?status=&severity=&search=&mine=true`, `GET /api/programs/:id`, `POST`, `PUT /:id`, `DELETE /:id` |
| Reports | `POST /api/reports` (multipart), `GET /my-reports`, `GET /company-reports`, `GET /:id`, `GET /:id/file`, `PUT /:id/status` |
| Leaderboards | `GET /api/leaderboard`, `GET /api/analytics/leaderboard/global`, `/seasonal`, `/country/:country` |
| Analytics | `/api/analytics/hacker/*`, `/api/analytics/company/*`, `/api/analytics/admin/*` |
| Community | `/api/feed`, `/api/extras/{marketplace,writeups,jobs,kb,breach-alerts}` |
| Other | `GET /api/notifications`, `GET /api/stats/public`, `GET /api/health` |
