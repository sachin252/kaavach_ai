# Kaavach AI v2.0: what was broken and what was fixed

Tested end to end on a fresh database (API smoke test of every route, headless browser crawl of every page for guest, researcher, company and admin, plus a full register > submit report > review > download > accept > live notification flow). Final run: zero page errors, zero failed API calls.

## Sections that were not working

| # | Section | Problem | Fix |
|---|---|---|---|
| 1 | Admin Analytics | Always "403 not allowed" because the role check received `[["admin"]]` | Role guard now accepts both styles; page shows users, programs, reports, active researchers, status chart, abuse watchlist |
| 2 | Hacker Dashboard | Crashed with "Failed to load dashboard data" as soon as a researcher had one accepted report (badges saved as text into an object field) | Badges stored correctly; dashboard rebuilt |
| 3 | Company analytics (dashboard + page) | Funnel, rewards and time-to-resolve were always empty or $0 (queried a `company` field that never existed) | Queries go through the company's programs; works for old data too |
| 4 | Company Dashboard | Showed every company's programs, not just your own; reviewer could not see the report text or open the attachment | Own programs only; review modal shows full description, researcher, severity, secure download, reward limited to program range |
| 5 | Marketplace / Writeups / Jobs / KB "View" links | Pages did not exist, clicking sent you to the home page | Four detail pages added (with delete for owner or admin) |
| 6 | Notifications "View all" | Route missing | Notifications page added; live socket alerts now authenticate and work |
| 7 | Job Board posting | Job type, salary, seniority and logo were silently dropped | Model matches the form |
| 8 | Breach Alerts | Domain, source and threat type silently dropped | Model matches the form |
| 9 | Writeups | Author, summary and category missing | Fixed |
| 10 | Leaderboard | Badges would crash the page; country tab always empty (no country on users) | Badge names render; country added to profile; XP and season rewards shown |
| 11 | Monthly activity charts | Month labels were blank | Last 12 months, zero-filled, labelled |
| 12 | XP / level | Level 1 showed negative progress; XP awarded again every time a report was re-accepted | New level curve; award once, reversed on reject |
| 13 | Program detail | Scope, activity chart and reputation numbers were fake or random | Real scope fields, real 6-month activity, real acceptance rate, payouts and response time |
| 14 | Header and every page | Hard-coded "124 programs, 312 reports, $1.8k", "Tier 2", "1260 XP" shown to everyone | Removed; home page shows live platform stats from `/api/stats/public` |
| 15 | Mobile menu | Invisible overlay sat on top of the menu, so links could not be clicked | Fixed |
| 16 | Forms and buttons | `.card`, `.btn-primary`, `.input-field` were used everywhere but never defined | Defined; all modals restyled consistently |
| 17 | Seed scripts | Did not match the models (crashed) and used a hard-coded admin password | Admin created from env vars on first boot; KB seed with real help articles |
| 18 | Submit from program page | "Submit a report" only opened the dashboard | Opens the submit form with that program pre-selected and only its allowed severities |
| 19 | Extras endpoints | Any error hung the request (no error handling) | All handlers wrapped; consistent JSON errors |
| 20 | Light theme | Half the UI stayed dark | App ships dark-only (toggle removed) until a full light palette is designed |

## Security fixes (important for a security product)

| Severity | Issue | Fix |
|---|---|---|
| Critical | `/api/analytics/leaderboard/*` returned full user documents including **password hashes** | Public fields only; hashes stripped from every response |
| Critical | Any logged-in user could read **any** vulnerability report (IDOR on `GET /api/reports/:id`) | Only researcher, program owner or admin |
| Critical | Uploaded reports were **public** at `/uploads/<file>` | Removed; authenticated download endpoint |
| High | Socket rooms joined by a user id sent by the client, so anyone could receive another user's notifications | Socket authenticates with JWT |
| High | Any user could create breach alerts and KB articles | Admin only; jobs limited to approved companies |
| High | Admin rejection of a company was undone on the company's next login | Removed auto re-approval |
| High | Program update accepted any field (could change owner) | Field allow-list |
| Medium | Leaderboards exposed researchers' emails | Removed |
| Medium | No rate limiting, no security headers, open CORS | Rate limits, Helmet with CSP and HSTS, CORS allow-list |
| Medium | NoSQL operator injection possible in request bodies | Sanitised |
| Medium | Default admin `admin123` | Env-based admin, 10+ char password; user passwords 8+ chars; change-password added |
| Low | Login page claimed "SOC 2 Ready", "ISO 27001", "Adaptive MFA" | Replaced with accurate statements |
| Low | Backend npm vulnerabilities (12) | `npm audit` now clean |

Known remaining item: the frontend has 3 advisories (zod, react-router) that need major-version upgrades. They affect client-side code only; schedule the upgrade with a regression test.

## Deployment

Single service (API serves the built React app). Added `Dockerfile`, `render.yaml` (Render blueprint with persistent disk), updated `railway.json`, root `package.json` build/start scripts, `.env.example` files, graceful shutdown, `/api/health` with DB status, code-split bundle, favicon, SEO meta and `robots.txt`. See README.

## Not built yet (recommended next)

- Email verification and password reset by email (needs an SMTP or email API key)
- Payment payouts (Razorpay/Stripe) for bounties and marketplace purchases; today rewards are recorded, not paid
- Object storage (S3/R2) for attachments if you run more than one server instance
- Terms of service, privacy policy and a disclosure policy page (legal content)
- Automated test suite in CI
