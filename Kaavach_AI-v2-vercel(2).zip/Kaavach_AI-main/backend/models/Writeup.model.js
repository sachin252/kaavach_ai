import mongoose from 'mongoose';

const writeupSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 200 },
  summary: { type: String, default: '', maxlength: 600 },
  content: { type: String, required: true, maxlength: 50000 },
  category: { type: String, default: 'Bug Bounty' },
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  authorName: { type: String, default: '' },
  tags: [{ type: String }],
}, { timestamps: true });

export default mongoose.model('Writeup', writeupSchema);
