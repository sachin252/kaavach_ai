import mongoose from 'mongoose';

const JobSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 140 },
  description: { type: String, required: true, maxlength: 8000 },
  companyId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  companyName: { type: String, default: '' },
  logoUrl: { type: String, default: '' },
  location: { type: String, default: '' },
  jobType: { type: String, default: 'Full-time' },
  seniority: { type: String, default: 'Mid' },
  salaryRange: { type: String, default: '' },
  applyUrl: { type: String, default: '' },
  tags: [String],
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.model('Job', JobSchema);
