import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { levelFromXp, tierFromLevel } from '../utils/xpEngine.js';

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 80 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 8, select: false },
    role: { type: String, enum: ['hacker', 'company', 'admin'], required: true },

    avatar: { type: String, default: '' },
    bio: { type: String, default: '', maxlength: 600 },
    country: { type: String, default: '', lowercase: true, trim: true },

    // Hacker metrics
    points: { type: Number, default: 0 },
    rank: { type: Number, default: 0 },
    badges: [{ name: String, icon: String, earnedAt: { type: Date, default: Date.now }, _id: false }],
    xp: { type: Number, default: 0 },
    level: { type: Number, default: 1 },
    tier: { type: String, default: 'Bronze' },
    streak: { type: Number, default: 0 },
    lastActive: { type: Date },
    impactScore: { type: Number, default: 0 },

    // Company metadata
    companyName: { type: String, default: '', trim: true },
    companyWebsite: { type: String, default: '', trim: true },
    isApproved: { type: Boolean, default: false },

    // Auth helpers
    isEmailVerified: { type: Boolean, default: false },
    resetPasswordToken: { type: String, select: false },
    resetPasswordExpire: { type: Date, select: false },
  },
  { timestamps: true }
);

userSchema.index({ role: 1, xp: -1 });
userSchema.index({ role: 1, country: 1 });

userSchema.pre('save', async function (next) {
  if (this.isModified('password')) {
    this.password = await bcrypt.hash(this.password, 12);
  }
  if (this.isModified('xp')) {
    this.level = levelFromXp(this.xp);
    this.tier = tierFromLevel(this.level);
  }
  next();
});

userSchema.methods.comparePassword = function (enteredPassword) {
  return bcrypt.compare(enteredPassword, this.password);
};

// Never leak secrets in any JSON response.
userSchema.set('toJSON', {
  transform: (_doc, ret) => {
    delete ret.password;
    delete ret.resetPasswordToken;
    delete ret.resetPasswordExpire;
    delete ret.__v;
    return ret;
  },
});

export const PUBLIC_USER_FIELDS = 'name avatar country xp level tier streak impactScore points badges';

export default mongoose.model('User', userSchema);
