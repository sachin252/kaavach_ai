import mongoose from 'mongoose';

const BreachAlertSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 200 },
  description: { type: String, required: true, maxlength: 5000 },
  severity: { type: String, enum: ['low', 'medium', 'high', 'critical'], default: 'medium' },
  affectedDomain: { type: String, default: '' },
  source: { type: String, default: '' },
  threatType: { type: String, default: '' },
  discoveredAt: Date,
  affectedAssets: [String],
  references: [String],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  isActive: { type: Boolean, default: true }
}, { timestamps: true });

export default mongoose.model('BreachAlert', BreachAlertSchema);
