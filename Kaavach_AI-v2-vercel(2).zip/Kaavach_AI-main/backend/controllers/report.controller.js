import Report from '../models/Report.model.js';
import Program from '../models/Program.model.js';
import User from '../models/User.model.js';
import { xpForSeverity, badgesFor, SEVERITY_POINTS, SEVERITY_IMPACT } from '../utils/xpEngine.js';
import { createAndEmitNotification } from './notification.controller.js';
import { asyncHandler, isValidId } from '../utils/http.js';
import { saveUpload, openUpload } from '../utils/upload.js';

const STATUSES = ['pending', 'accepted', 'rejected', 'triaged', 'duplicate'];
const SEVERITIES = ['low', 'medium', 'high', 'critical'];

const removeUpload = () => {}; // files are only persisted after validation

// Recompute a hacker's badges from their accepted reports.
async function refreshBadges(user, current) {
  const agg = await Report.aggregate([
    { $match: { submittedBy: user._id, status: 'accepted' } },
    { $group: { _id: null, accepted: { $sum: 1 }, critical: { $sum: { $cond: [{ $eq: ['$severity', 'critical'] }, 1, 0] } } } },
  ]);
  // `current` is the report being accepted right now (not yet saved as accepted)
  const extra = current ? 1 : 0;
  const extraCrit = current?.severity === 'critical' ? 1 : 0;
  const earned = badgesFor({
    accepted: (agg[0]?.accepted || 0) + extra,
    critical: (agg[0]?.critical || 0) + extraCrit,
    points: user.points,
  });
  const have = new Set((user.badges || []).map((b) => b.name));
  const fresh = earned.filter((b) => !have.has(b.name)).map((b) => ({ ...b, earnedAt: new Date() }));
  if (fresh.length) user.badges = [...(user.badges || []), ...fresh];
  return fresh;
}

// Award XP/points exactly once per report (idempotent on repeated "accepted").
async function awardForAcceptance(report) {
  if (report.xpAwarded > 0) return { xp: 0, newBadges: [] };
  const user = await User.findById(report.submittedBy);
  if (!user) return { xp: 0, newBadges: [] };

  const xp = xpForSeverity(report.severity);
  const pts = SEVERITY_POINTS[report.severity] || 0;
  user.xp = (user.xp || 0) + xp;
  user.points = (user.points || 0) + pts;
  user.impactScore = (user.impactScore || 0) + (SEVERITY_IMPACT[report.severity] || 0);

  const now = new Date();
  if (user.lastActive) {
    const diffDays = (now - new Date(user.lastActive)) / 86400000;
    user.streak = diffDays <= 2 ? (user.streak || 0) + 1 : 1;
  } else user.streak = 1;
  user.lastActive = now;

  const newBadges = await refreshBadges(user, report);
  await user.save();

  report.xpAwarded = xp;
  report.pointsAwarded = pts;
  return { xp, newBadges };
}

// Reverse an earlier award if a report is moved away from "accepted".
async function revokeAward(report) {
  if (!report.xpAwarded && !report.pointsAwarded) return;
  const user = await User.findById(report.submittedBy);
  if (user) {
    user.xp = Math.max(0, (user.xp || 0) - (report.xpAwarded || 0));
    user.points = Math.max(0, (user.points || 0) - (report.pointsAwarded || 0));
    user.impactScore = Math.max(0, (user.impactScore || 0) - (SEVERITY_IMPACT[report.severity] || 0));
    await user.save();
  }
  report.xpAwarded = 0;
  report.pointsAwarded = 0;
}

const canView = (report, user) => {
  if (user.role === 'admin') return true;
  const owner = report.program?.createdBy?._id || report.program?.createdBy;
  const submitter = report.submittedBy?._id || report.submittedBy;
  return String(submitter) === String(user._id) || String(owner) === String(user._id);
};

// POST /api/reports  (hacker, multipart)
export const submitReport = asyncHandler(async (req, res) => {
  const { program, title, description, severity } = req.body;

  if (!program || !title || !description || !severity || !req.file) {
    removeUpload(req.file);
    return res.status(400).json({ message: 'Please provide all required fields and attach a PDF/DOCX file' });
  }
  if (!isValidId(program) || !SEVERITIES.includes(severity)) {
    removeUpload(req.file);
    return res.status(400).json({ message: 'Invalid program or severity' });
  }

  const programDoc = await Program.findById(program);
  if (!programDoc) {
    removeUpload(req.file);
    return res.status(404).json({ message: 'Program not found' });
  }
  if (programDoc.status !== 'active') {
    removeUpload(req.file);
    return res.status(400).json({ message: 'Program is not accepting reports' });
  }
  if (!programDoc.severityLevels.includes(severity)) {
    removeUpload(req.file);
    return res.status(400).json({ message: `This program only accepts: ${programDoc.severityLevels.join(', ')}` });
  }

  const fileRef = await saveUpload(req.file, { uploadedBy: String(req.user._id), program: String(program) });

  const report = await Report.create({
    program,
    company: programDoc.createdBy,
    submittedBy: req.user._id,
    title: String(title).slice(0, 200),
    description: String(description).slice(0, 20000),
    severity,
    fileUrl: fileRef,
    fileName: req.file.originalname.slice(0, 200),
  });

  await Program.updateOne({ _id: programDoc._id }, { $push: { reports: report._id } });

  const populated = await Report.findById(report._id)
    .populate('program', 'title')
    .populate('submittedBy', 'name xp level tier streak');

  createAndEmitNotification(
    programDoc.createdBy,
    `New report for ${programDoc.title}`,
    `${req.user.name} submitted "${report.title}" (${severity}).`,
    `/dashboard/company`,
    { reportId: report._id, programId: programDoc._id }
  ).catch((err) => console.error('Notification error (submitReport):', err.message));

  res.status(201).json(populated);
});

// GET /api/reports/my-reports
export const getMyReports = asyncHandler(async (req, res) => {
  const reports = await Report.find({ submittedBy: req.user._id })
    .populate('program', 'title status')
    .sort({ createdAt: -1 });
  res.json(reports);
});

// GET /api/reports/company-reports
export const getCompanyReports = asyncHandler(async (req, res) => {
  const filter = {};
  if (req.user.role !== 'admin') {
    const programIds = await Program.find({ createdBy: req.user._id }).distinct('_id');
    filter.program = { $in: programIds };
  }
  if (req.query.status && STATUSES.includes(req.query.status)) filter.status = req.query.status;

  const reports = await Report.find(filter)
    .populate('program', 'title rewardRange')
    .populate('submittedBy', 'name points xp level tier streak')
    .sort({ createdAt: -1 })
    .limit(500);
  res.json(reports);
});

// GET /api/reports/:id  (submitter, program owner or admin only)
export const getReport = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return res.status(404).json({ message: 'Report not found' });
  const report = await Report.findById(req.params.id)
    .populate('program', 'title description createdBy rewardRange')
    .populate('submittedBy', 'name xp level tier streak points')
    .populate('reviewedBy', 'name');
  if (!report || !canView(report, req.user)) return res.status(404).json({ message: 'Report not found' });
  res.json(report);
});

// GET /api/reports/:id/file  (authenticated download)
export const downloadReportFile = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return res.status(404).json({ message: 'Report not found' });
  const report = await Report.findById(req.params.id).populate('program', 'createdBy');
  if (!report || !canView(report, req.user)) return res.status(404).json({ message: 'Report not found' });

  const file = await openUpload(report.fileUrl);
  if (!file) return res.status(404).json({ message: 'Attachment not found on server' });

  const safeName = (report.fileName || 'report').replace(/[^\w.\- ]+/g, '_');
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${safeName}"; filename*=UTF-8''${encodeURIComponent(report.fileName || 'report')}`);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Cache-Control', 'private, no-store');
  if (file.length) res.setHeader('Content-Length', file.length);
  file.stream.on('error', () => res.destroy());
  file.stream.pipe(res);
});

// PUT /api/reports/:id/status  (program owner or admin)
export const updateReportStatus = asyncHandler(async (req, res) => {
  const { status, reward, reviewNotes } = req.body;
  if (!STATUSES.includes(status)) return res.status(400).json({ message: 'Invalid status' });
  if (!isValidId(req.params.id)) return res.status(404).json({ message: 'Report not found' });

  const report = await Report.findById(req.params.id).populate('program');
  if (!report) return res.status(404).json({ message: 'Report not found' });
  if (String(report.program.createdBy) !== String(req.user._id) && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Not authorized' });
  }

  const rewardNum = reward === undefined || reward === '' ? report.reward : Number(reward);
  if (!Number.isFinite(rewardNum) || rewardNum < 0) return res.status(400).json({ message: 'Reward must be a positive number' });
  const max = report.program.rewardRange?.max;
  if (status === 'accepted' && max && rewardNum > max) {
    return res.status(400).json({ message: `Reward cannot exceed the program maximum of ${max}` });
  }

  const previous = report.status;
  report.status = status;
  report.reviewedBy = req.user._id;
  if (reviewNotes !== undefined) report.reviewNotes = String(reviewNotes).slice(0, 5000);
  report.reward = status === 'accepted' ? rewardNum : 0;
  report.rewardGiven = status === 'accepted' && rewardNum > 0;
  if (status !== 'pending' && !report.resolvedAt) report.resolvedAt = new Date();

  let xpAwarded = 0;
  let newBadges = [];
  if (status === 'accepted') ({ xp: xpAwarded, newBadges } = await awardForAcceptance(report));
  else if (previous === 'accepted') await revokeAward(report);

  await report.save();
  await report.populate('submittedBy', 'name xp level tier streak points');

  if (previous !== status) {
    createAndEmitNotification(
      report.submittedBy._id,
      `Report ${status}`,
      `Your report "${report.title}" was marked as ${status}${status === 'accepted' && report.reward ? ` with a $${report.reward} reward` : ''}.`,
      `/dashboard/hacker`,
      { reportId: report._id, status, xpAwarded, badges: newBadges.map((b) => b.name) }
    ).catch((err) => console.error('Notification error (updateReportStatus):', err.message));
  }

  res.json({ success: true, message: 'Report updated successfully', report: report.toObject(), xpAwarded });
});
