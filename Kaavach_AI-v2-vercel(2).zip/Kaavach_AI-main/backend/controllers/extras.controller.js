import slugify from 'slugify';
import MarketplaceItem from '../models/MarketplaceItem.model.js';
import Writeup from '../models/Writeup.model.js';
import Job from '../models/Job.model.js';
import KBArticle from '../models/KBArticle.model.js';
import BreachAlert from '../models/BreachAlert.model.js';
import { asyncHandler, isValidId, pick, toTagList, paging } from '../utils/http.js';

const isUrl = (v) => !v || /^https?:\/\/[^\s]+$/i.test(String(v));
const notFound = (res, what) => res.status(404).json({ message: `${what} not found` });
const canManage = (doc, user, ownerField) => user.role === 'admin' || String(doc[ownerField]) === String(user._id);

const removeOwned = (Model, ownerField, label) =>
  asyncHandler(async (req, res) => {
    if (!isValidId(req.params.id)) return notFound(res, label);
    const doc = await Model.findById(req.params.id);
    if (!doc) return notFound(res, label);
    if (!canManage(doc, req.user, ownerField)) return res.status(403).json({ message: 'Not authorized' });
    await doc.deleteOne();
    res.json({ message: `${label} deleted` });
  });

/* ===================== MARKETPLACE ===================== */
export const listMarketplace = asyncHandler(async (req, res) => {
  const { limit } = paging(req.query, 50, 200);
  const items = await MarketplaceItem.find({ isPublished: true })
    .populate('sellerId', 'name companyName')
    .sort({ createdAt: -1 })
    .limit(limit);
  res.json({ items });
});

export const getMarketplaceItem = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return notFound(res, 'Item');
  const item = await MarketplaceItem.findById(req.params.id).populate('sellerId', 'name companyName');
  if (!item) return notFound(res, 'Item');
  res.json(item);
});

export const createMarketplaceItem = asyncHandler(async (req, res) => {
  const data = pick(req.body, ['title', 'description', 'price']);
  if (!data.title || !data.description) return res.status(400).json({ message: 'Title and description are required' });
  const attachments = toTagList(req.body.attachments);
  if (!attachments.every(isUrl)) return res.status(400).json({ message: 'Attachments must be http(s) URLs' });
  const item = await MarketplaceItem.create({
    ...data,
    price: Math.max(0, Number(data.price) || 0),
    tags: toTagList(req.body.tags).map((t) => t.toLowerCase()),
    attachments,
    sellerId: req.user._id,
  });
  res.status(201).json(item);
});
export const deleteMarketplaceItem = removeOwned(MarketplaceItem, 'sellerId', 'Item');

/* ===================== WRITEUPS ===================== */
export const listWriteups = asyncHandler(async (req, res) => {
  const { limit } = paging(req.query, 50, 200);
  const writeups = await Writeup.find()
    .select('-content')
    .populate('author', 'name avatar')
    .sort({ createdAt: -1 })
    .limit(limit);
  res.json({ writeups });
});

export const getWriteup = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return notFound(res, 'Writeup');
  const item = await Writeup.findById(req.params.id).populate('author', 'name avatar tier');
  if (!item) return notFound(res, 'Writeup');
  res.json(item);
});

export const createWriteup = asyncHandler(async (req, res) => {
  const data = pick(req.body, ['title', 'summary', 'content', 'category']);
  if (!data.title || !data.content) return res.status(400).json({ message: 'Title and content are required' });
  const w = await Writeup.create({
    ...data,
    tags: toTagList(req.body.tags),
    author: req.user._id,
    authorName: req.user.name,
  });
  res.status(201).json(w);
});
export const deleteWriteup = removeOwned(Writeup, 'author', 'Writeup');

/* ===================== JOBS ===================== */
export const listJobs = asyncHandler(async (req, res) => {
  const { limit } = paging(req.query, 50, 200);
  const jobs = await Job.find({ isActive: true }).populate('companyId', 'name companyName avatar').sort({ createdAt: -1 }).limit(limit);
  res.json({ jobs });
});

export const getJob = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return notFound(res, 'Job');
  const job = await Job.findById(req.params.id).populate('companyId', 'name companyName companyWebsite');
  if (!job) return notFound(res, 'Job');
  res.json(job);
});

export const createJob = asyncHandler(async (req, res) => {
  const data = pick(req.body, ['title', 'description', 'location', 'jobType', 'seniority', 'salaryRange', 'applyUrl', 'logoUrl']);
  if (!data.title || !data.description) return res.status(400).json({ message: 'Title and description are required' });
  if (!isUrl(data.applyUrl) || !isUrl(data.logoUrl)) return res.status(400).json({ message: 'Links must start with http:// or https://' });
  const job = await Job.create({
    ...data,
    tags: toTagList(req.body.tags),
    companyId: req.user._id,
    companyName: req.user.companyName || req.user.name,
  });
  res.status(201).json(job);
});
export const deleteJob = removeOwned(Job, 'companyId', 'Job');

/* ===================== KNOWLEDGE BASE ===================== */
export const listKB = asyncHandler(async (req, res) => {
  const articles = await KBArticle.find({ published: true }).select('-content').sort({ createdAt: -1 }).limit(200);
  res.json({ articles });
});

export const getKBArticle = asyncHandler(async (req, res) => {
  const article = await KBArticle.findOne({ slug: String(req.params.slug), published: true }).populate('author', 'name');
  if (!article) return notFound(res, 'Article');
  res.json(article);
});

export const createKBArticle = asyncHandler(async (req, res) => {
  const data = pick(req.body, ['title', 'summary', 'content', 'category', 'readTime', 'slug']);
  if (!data.title || !data.summary || !data.content) return res.status(400).json({ message: 'Title, summary and content are required' });
  let base = slugify(data.slug || data.title, { lower: true, strict: true }) || 'article';
  let slug = base;
  for (let i = 2; await KBArticle.exists({ slug }); i++) slug = `${base}-${i}`;
  const article = await KBArticle.create({ ...data, slug, tags: toTagList(req.body.tags), author: req.user._id });
  res.status(201).json(article);
});
export const deleteKBArticle = removeOwned(KBArticle, 'author', 'Article');

/* ===================== BREACH ALERTS ===================== */
export const listBreachAlerts = asyncHandler(async (req, res) => {
  const alerts = await BreachAlert.find({ isActive: true }).sort({ createdAt: -1 }).limit(200);
  res.json({ alerts });
});

export const createBreachAlert = asyncHandler(async (req, res) => {
  const data = pick(req.body, ['title', 'description', 'severity', 'affectedDomain', 'source', 'threatType']);
  if (!data.title || !data.description) return res.status(400).json({ message: 'Title and description are required' });
  const alert = await BreachAlert.create({ ...data, createdBy: req.user._id, discoveredAt: new Date() });
  res.status(201).json(alert);
});
export const deleteBreachAlert = removeOwned(BreachAlert, 'createdBy', 'Alert');
