import User from '../models/User.model.js';
import { generateToken } from '../utils/generateToken.js';
import { asyncHandler, pick } from '../utils/http.js';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const authPayload = (user) => ({ ...user.toJSON(), token: generateToken(user._id) });

// POST /api/auth/register
export const register = asyncHandler(async (req, res) => {
  const { name, email, password, role, companyName, companyWebsite, country } = req.body;

  if (!name || !email || !password || !role) {
    return res.status(400).json({ message: 'Please provide all required fields' });
  }
  if (!['hacker', 'company'].includes(role)) {
    return res.status(400).json({ message: 'Invalid role' });
  }
  if (!EMAIL_RE.test(String(email))) return res.status(400).json({ message: 'Please enter a valid email' });
  if (String(password).length < 8) {
    return res.status(400).json({ message: 'Password must be at least 8 characters' });
  }
  if (role === 'company' && !companyName) {
    return res.status(400).json({ message: 'Company name is required' });
  }

  const exists = await User.exists({ email: String(email).toLowerCase().trim() });
  if (exists) return res.status(400).json({ message: 'An account with this email already exists' });

  const user = await User.create({
    name: String(name).trim(),
    email,
    password,
    role,
    country: country || '',
    ...(role === 'company' && {
      companyName: companyName || '',
      companyWebsite: companyWebsite || '',
      // Set COMPANY_AUTO_APPROVE=false to require admin approval for new companies.
      isApproved: process.env.COMPANY_AUTO_APPROVE !== 'false',
    }),
  });

  res.status(201).json(authPayload(user));
});

// POST /api/auth/login
export const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Please provide email and password' });
  }
  const user = await User.findOne({ email: String(email).toLowerCase().trim() }).select('+password');
  if (!user || !(await user.comparePassword(String(password)))) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }
  res.json(authPayload(user));
});

// GET /api/auth/me
export const getMe = asyncHandler(async (req, res) => {
  res.json(req.user);
});

// PUT /api/auth/profile
export const updateProfile = asyncHandler(async (req, res) => {
  const allowed = ['name', 'bio', 'avatar', 'country'];
  if (req.user.role === 'company') allowed.push('companyName', 'companyWebsite');
  const updateData = pick(req.body, allowed);
  if (updateData.name !== undefined && !String(updateData.name).trim()) {
    return res.status(400).json({ message: 'Name cannot be empty' });
  }
  const user = await User.findByIdAndUpdate(req.user._id, updateData, { new: true, runValidators: true });
  res.json(user);
});

// PUT /api/auth/password
export const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword || String(newPassword).length < 8) {
    return res.status(400).json({ message: 'New password must be at least 8 characters' });
  }
  const user = await User.findById(req.user._id).select('+password');
  if (!(await user.comparePassword(String(currentPassword)))) {
    return res.status(400).json({ message: 'Current password is incorrect' });
  }
  user.password = newPassword;
  await user.save();
  res.json({ message: 'Password updated' });
});
