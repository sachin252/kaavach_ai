import User, { PUBLIC_USER_FIELDS } from '../models/User.model.js';
import Report from '../models/Report.model.js';
import { asyncHandler } from '../utils/http.js';

// GET /api/leaderboard  (points based, public fields only)
export const getLeaderboard = asyncHandler(async (req, res) => {
  const hackers = await User.find({ role: 'hacker' })
    .select(PUBLIC_USER_FIELDS)
    .sort({ points: -1, xp: -1, createdAt: 1 })
    .limit(100)
    .lean();
  res.json(hackers.map((h, i) => ({ ...h, rank: i + 1 })));
});

// GET /api/leaderboard/my-stats
export const getMyStats = asyncHandler(async (req, res) => {
  const me = req.user;
  const [agg, ahead] = await Promise.all([
    Report.aggregate([
      { $match: { submittedBy: me._id } },
      {
        $group: {
          _id: null,
          total: { $sum: 1 },
          accepted: { $sum: { $cond: [{ $eq: ['$status', 'accepted'] }, 1, 0] } },
          pending: { $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] } },
          rewards: { $sum: { $cond: [{ $eq: ['$status', 'accepted'] }, '$reward', 0] } },
        },
      },
    ]),
    User.countDocuments({ role: 'hacker', points: { $gt: me.points || 0 } }),
  ]);
  const a = agg[0] || {};
  res.json({
    totalReports: a.total || 0,
    acceptedReports: a.accepted || 0,
    pendingReports: a.pending || 0,
    totalRewards: a.rewards || 0,
    points: me.points || 0,
    rank: ahead + 1,
    xp: me.xp,
    level: me.level,
    tier: me.tier,
    streak: me.streak,
    badges: me.badges || [],
  });
});
