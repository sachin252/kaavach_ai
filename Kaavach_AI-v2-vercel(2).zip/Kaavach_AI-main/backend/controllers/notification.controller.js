import Notification from '../models/Notification.model.js';
import { emitNotificationToUser } from '../utils/socket.js';
import { asyncHandler, isValidId } from '../utils/http.js';

export const createAndEmitNotification = async (userId, title, body, link = null, data = {}) => {
  const note = await Notification.create({ user: userId, title, body, link, data });
  try {
    emitNotificationToUser(userId.toString(), {
      _id: note._id, title: note.title, body: note.body, link: note.link,
      data: note.data, read: note.read, createdAt: note.createdAt,
    });
  } catch (e) {
    console.error('Emit notification error:', e.message);
  }
  return note;
};

export const getMyNotifications = asyncHandler(async (req, res) => {
  const notes = await Notification.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(100);
  res.json(notes);
});

export const markNotificationRead = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return res.status(404).json({ message: 'Not found' });
  await Notification.findOneAndUpdate({ _id: req.params.id, user: req.user._id }, { read: true });
  res.json({ ok: true });
});

export const markAllRead = asyncHandler(async (req, res) => {
  await Notification.updateMany({ user: req.user._id, read: false }, { read: true });
  res.json({ ok: true });
});
