import User, { PUBLIC_USER_FIELDS } from '../models/User.model.js';
import Report from '../models/Report.model.js';
import { asyncHandler } from '../utils/http.js';

// XP ranked, public fields only
export const getGlobalLeaderboard = asyncHandler(async (req, res) => {
  const users = await User.find({ role: 'hacker' })
    .select(PUBLIC_USER_FIELDS)
    .sort({ xp: -1, points: -1, createdAt: 1 })
    .limit(100)
    .lean();
  res.json(users);
});

// Rewards earned in the last 3 months
export const getSeasonalLeaderboard = asyncHandler(async (req, res) => {
  const startOfSeason = new Date();
  startOfSeason.setMonth(startOfSeason.getMonth() - 3);

  const seasonal = await Report.aggregate([
    { $match: { createdAt: { $gte: startOfSeason }, status: 'accepted' } },
    { $group: { _id: '$submittedBy', reports: { $sum: 1 }, reward: { $sum: '$reward' }, seasonXp: { $sum: '$xpAwarded' } } },
    { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'hacker' } },
    { $unwind: '$hacker' },
    {
      $project: {
        name: '$hacker.name',
        avatar: '$hacker.avatar',
        country: '$hacker.country',
        reward: 1,
        reports: 1,
        seasonXp: 1,
        points: '$hacker.points',
        xp: '$hacker.xp',
        level: '$hacker.level',
        tier: '$hacker.tier',
        badges: '$hacker.badges',
      },
    },
    { $sort: { reward: -1, seasonXp: -1 } },
    { $limit: 50 },
  ]);
  res.json(seasonal);
});

export const getCountryLeaderboard = asyncHandler(async (req, res) => {
  const country = String(req.params.country || '').toLowerCase().slice(0, 40);
  const users = await User.find({ role: 'hacker', country })
    .select(PUBLIC_USER_FIELDS)
    .sort({ xp: -1 })
    .limit(50)
    .lean();
  res.json(users);
});
