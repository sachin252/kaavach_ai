import Report from '../models/Report.model.js';
import Program from '../models/Program.model.js';
import User from '../models/User.model.js';
import { asyncHandler } from '../utils/http.js';
import { SEVERITY_IMPACT } from '../utils/xpEngine.js';

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

// Reports belonging to programs owned by this company (works for legacy reports without `company`).
const companyMatch = async (userId) => {
  const programIds = await Program.find({ createdBy: userId }).distinct('_id');
  return { program: { $in: programIds } };
};

/* ---------------- HACKER ---------------- */
export const getHackerSeverityStats = asyncHandler(async (req, res) => {
  res.json(await Report.aggregate([{ $match: { submittedBy: req.user._id } }, { $group: { _id: '$severity', count: { $sum: 1 } } }]));
});

// Last 12 months, zero-filled, each item: { _id, label, month, count }
export const getHackerMonthlyActivity = asyncHandler(async (req, res) => {
  const since = new Date();
  since.setMonth(since.getMonth() - 11, 1);
  since.setHours(0, 0, 0, 0);
  const agg = await Report.aggregate([
    { $match: { submittedBy: req.user._id, createdAt: { $gte: since } } },
    { $group: { _id: { month: { $month: '$createdAt' }, year: { $year: '$createdAt' } }, count: { $sum: 1 } } },
  ]);
  const out = [];
  for (let i = 11; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i, 1);
    const m = d.getMonth() + 1;
    const y = d.getFullYear();
    const hit = agg.find((a) => a._id.month === m && a._id.year === y);
    out.push({ _id: `${MONTHS[m - 1]} ${String(y).slice(2)}`, label: `${MONTHS[m - 1]} ${y}`, month: MONTHS[m - 1], year: y, count: hit?.count || 0 });
  }
  res.json(out);
});

export const getHackerAcceptanceStats = asyncHandler(async (req, res) => {
  res.json(await Report.aggregate([{ $match: { submittedBy: req.user._id } }, { $group: { _id: '$status', count: { $sum: 1 } } }]));
});

export const getHackerImpactScore = asyncHandler(async (req, res) => {
  const agg = await Report.aggregate([
    { $match: { submittedBy: req.user._id, status: 'accepted' } },
    { $group: { _id: '$severity', count: { $sum: 1 } } },
  ]);
  const impactScore = agg.reduce((s, a) => s + (SEVERITY_IMPACT[a._id] || 0) * a.count, 0);
  res.json({ impactScore });
});

export const getHackerSummary = asyncHandler(async (req, res) => {
  const id = req.user._id;
  const [accepted, total, rewards, programs, ahead] = await Promise.all([
    Report.countDocuments({ submittedBy: id, status: 'accepted' }),
    Report.countDocuments({ submittedBy: id }),
    Report.aggregate([{ $match: { submittedBy: id, status: 'accepted' } }, { $group: { _id: null, total: { $sum: '$reward' } } }]),
    Report.distinct('program', { submittedBy: id }),
    User.countDocuments({ role: 'hacker', xp: { $gt: req.user.xp || 0 } }),
  ]);
  res.json({
    accepted,
    total,
    totalReports: total,
    acceptanceRate: total ? Math.round((accepted / total) * 100) : 0,
    totalRewards: rewards[0]?.total || 0,
    programsContributed: programs.length,
    rank: ahead + 1,
    user: { xp: req.user.xp, level: req.user.level, tier: req.user.tier, streak: req.user.streak, badges: req.user.badges, impactScore: req.user.impactScore },
  });
});

/* ---------------- COMPANY ---------------- */
export const getCompanyReportFunnel = asyncHandler(async (req, res) => {
  const match = await companyMatch(req.user._id);
  res.json(await Report.aggregate([{ $match: match }, { $group: { _id: '$status', count: { $sum: 1 } } }]));
});

export const getCompanyRewardSummary = asyncHandler(async (req, res) => {
  const match = await companyMatch(req.user._id);
  const r = await Report.aggregate([
    { $match: { ...match, status: 'accepted' } },
    { $group: { _id: null, totalRewards: { $sum: '$reward' }, avgReward: { $avg: '$reward' }, count: { $sum: 1 } } },
  ]);
  res.json({ totalRewards: r[0]?.totalRewards || 0, avgReward: Math.round((r[0]?.avgReward || 0) * 100) / 100, paidReports: r[0]?.count || 0 });
});

export const getCompanyTTR = asyncHandler(async (req, res) => {
  const match = await companyMatch(req.user._id);
  const stats = await Report.aggregate([
    { $match: { ...match, status: { $ne: 'pending' } } },
    { $project: { diff: { $divide: [{ $subtract: [{ $ifNull: ['$resolvedAt', '$updatedAt'] }, '$createdAt'] }, 86400000] } } },
    { $group: { _id: null, avgTTR: { $avg: '$diff' } } },
  ]);
  res.json({ avgTTR: stats[0]?.avgTTR || 0 });
});

export const getCompanyProgramInsights = asyncHandler(async (req, res) => {
  const match = await companyMatch(req.user._id);
  const insights = await Report.aggregate([
    { $match: match },
    {
      $group: {
        _id: '$program',
        reports: { $sum: 1 },
        accepted: { $sum: { $cond: [{ $eq: ['$status', 'accepted'] }, 1, 0] } },
        paid: { $sum: { $cond: [{ $eq: ['$status', 'accepted'] }, '$reward', 0] } },
      },
    },
    { $lookup: { from: 'programs', localField: '_id', foreignField: '_id', as: 'program' } },
    { $unwind: '$program' },
    { $project: { title: '$program.title', status: '$program.status', reports: 1, accepted: 1, paid: 1 } },
    { $sort: { reports: -1 } },
  ]);
  res.json(insights);
});

/* ---------------- ADMIN ---------------- */
export const getAdminOverview = asyncHandler(async (req, res) => {
  const now = Date.now();
  const [users, hackers, companies, programs, reports, dau, mau, byStatus] = await Promise.all([
    User.countDocuments(),
    User.countDocuments({ role: 'hacker' }),
    User.countDocuments({ role: 'company' }),
    Program.countDocuments(),
    Report.countDocuments(),
    Report.distinct('submittedBy', { createdAt: { $gte: new Date(now - 86400000) } }),
    Report.distinct('submittedBy', { createdAt: { $gte: new Date(now - 30 * 86400000) } }),
    Report.aggregate([{ $group: { _id: '$status', count: { $sum: 1 } } }]),
  ]);
  res.json({ users, hackers, companies, programs, reports, dau: dau.length, mau: mau.length, byStatus });
});

// Hackers with >= 5 reports where at least half are duplicate/rejected
export const getAbuseDetection = asyncHandler(async (req, res) => {
  const result = await Report.aggregate([
    {
      $group: {
        _id: '$submittedBy',
        total: { $sum: 1 },
        bad: { $sum: { $cond: [{ $in: ['$status', ['duplicate', 'rejected']] }, 1, 0] } },
      },
    },
    { $match: { total: { $gte: 5 }, $expr: { $gte: ['$bad', { $multiply: ['$total', 0.5] }] } } },
    { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
    { $unwind: '$user' },
    { $project: { total: 1, bad: 1, name: '$user.name', email: '$user.email', ratio: { $divide: ['$bad', '$total'] } } },
    { $sort: { ratio: -1 } },
  ]);
  res.json(result);
});
