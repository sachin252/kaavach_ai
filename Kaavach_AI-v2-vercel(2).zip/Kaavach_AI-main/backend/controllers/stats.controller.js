import Program from '../models/Program.model.js';
import Report from '../models/Report.model.js';
import User from '../models/User.model.js';
import { asyncHandler } from '../utils/http.js';

let cache = { at: 0, data: null };

// GET /api/stats/public  -- real platform numbers for the landing page (cached 60s)
export const getPublicStats = asyncHandler(async (req, res) => {
  if (cache.data && Date.now() - cache.at < 60000) return res.json(cache.data);

  const dayAgo = new Date(Date.now() - 86400000);
  const monthAgo = new Date(Date.now() - 30 * 86400000);
  const [activePrograms, newPrograms, reportsToday, totalReports, researchers, companies, rewards, sla] = await Promise.all([
    Program.countDocuments({ status: 'active' }),
    Program.countDocuments({ createdAt: { $gte: monthAgo } }),
    Report.countDocuments({ createdAt: { $gte: dayAgo } }),
    Report.countDocuments(),
    User.countDocuments({ role: 'hacker' }),
    User.countDocuments({ role: 'company' }),
    Report.aggregate([{ $match: { status: 'accepted' } }, { $group: { _id: null, total: { $sum: '$reward' }, avg: { $avg: '$reward' } } }]),
    Report.aggregate([
      { $match: { resolvedAt: { $ne: null } } },
      { $group: { _id: null, hours: { $avg: { $divide: [{ $subtract: ['$resolvedAt', '$createdAt'] }, 3600000] } } } },
    ]),
  ]);

  cache = {
    at: Date.now(),
    data: {
      activePrograms,
      newProgramsLast30Days: newPrograms,
      reportsToday,
      totalReports,
      researchers,
      companies,
      totalRewards: rewards[0]?.total || 0,
      avgBounty: Math.round(rewards[0]?.avg || 0),
      avgResponseHours: sla[0] ? Math.round(sla[0].hours) : null,
    },
  };
  res.json(cache.data);
});
