import Feed from '../models/Feed.model.js';
import { asyncHandler, isValidId, paging, toTagList } from '../utils/http.js';

const TYPES = ['achievement', 'job', 'freelance', 'general'];
const populateAll = (q) =>
  q.populate('author', 'name role avatar companyName')
    .populate('likes.user', 'name avatar')
    .populate('comments.user', 'name avatar');

// GET /api/feed?type=&page=&limit=
export const getFeed = asyncHandler(async (req, res) => {
  const { type } = req.query;
  const { page, limit, skip } = paging(req.query, 30, 100);
  const query = { isDeleted: false };
  if (TYPES.includes(type)) query.type = type;

  const [posts, total] = await Promise.all([
    populateAll(Feed.find(query)).sort({ createdAt: -1 }).skip(skip).limit(limit),
    Feed.countDocuments(query),
  ]);
  res.json({ posts, totalPages: Math.ceil(total / limit), currentPage: page, total });
});

// POST /api/feed
export const createPost = asyncHandler(async (req, res) => {
  const { type, title, content, image, jobDetails } = req.body;
  if (!type || !title || !content) return res.status(400).json({ message: 'Please provide all required fields' });
  if (!TYPES.includes(type)) return res.status(400).json({ message: 'Invalid post type' });

  const postData = {
    author: req.user._id,
    type,
    title: String(title).slice(0, 200),
    content: String(content).slice(0, 10000),
  };
  if (image && /^https?:\/\//i.test(image)) postData.image = String(image).slice(0, 500);
  if (jobDetails && (type === 'job' || type === 'freelance')) {
    postData.jobDetails = {
      position: jobDetails.position,
      location: jobDetails.location,
      salary: jobDetails.salary,
      requirements: toTagList(jobDetails.requirements),
      deadline: jobDetails.deadline || undefined,
    };
  }
  const post = await Feed.create(postData);
  res.status(201).json(await populateAll(Feed.findById(post._id)));
});

const loadPost = async (req, res) => {
  if (!isValidId(req.params.id)) {
    res.status(404).json({ message: 'Post not found' });
    return null;
  }
  const post = await Feed.findOne({ _id: req.params.id, isDeleted: false });
  if (!post) res.status(404).json({ message: 'Post not found' });
  return post;
};

// POST /api/feed/:id/like
export const toggleLike = asyncHandler(async (req, res) => {
  const post = await loadPost(req, res);
  if (!post) return;
  const idx = post.likes.findIndex((l) => String(l.user) === String(req.user._id));
  if (idx > -1) post.likes.splice(idx, 1);
  else post.likes.push({ user: req.user._id });
  await post.save();
  res.json(await populateAll(Feed.findById(post._id)));
});

// POST /api/feed/:id/comment
export const addComment = asyncHandler(async (req, res) => {
  const text = String(req.body.text || '').trim();
  if (!text) return res.status(400).json({ message: 'Comment text is required' });
  const post = await loadPost(req, res);
  if (!post) return;
  post.comments.push({ user: req.user._id, text: text.slice(0, 2000) });
  await post.save();
  res.json(await populateAll(Feed.findById(post._id)));
});

// DELETE /api/feed/:id
export const deletePost = asyncHandler(async (req, res) => {
  const post = await loadPost(req, res);
  if (!post) return;
  if (String(post.author) !== String(req.user._id) && req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Not authorized' });
  }
  post.isDeleted = true;
  await post.save();
  res.json({ message: 'Post deleted' });
});
