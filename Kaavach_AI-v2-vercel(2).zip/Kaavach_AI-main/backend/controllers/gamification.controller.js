import User from '../models/User.model.js';
import Report from '../models/Report.model.js';
import { xpForSeverity, badgesFor, SEVERITY_POINTS, SEVERITY_IMPACT } from '../utils/xpEngine.js';

// Rebuild a hacker's XP, points, impact and badges from their accepted reports.
export async function recalcUserGamification(userId) {
  const user = await User.findById(userId);
  if (!user) throw new Error('User not found');

  const reports = await Report.find({ submittedBy: user._id, status: 'accepted' });
  let xp = 0, points = 0, impact = 0, critical = 0;
  for (const r of reports) {
    const rx = r.xpAwarded || xpForSeverity(r.severity);
    const rp = r.pointsAwarded || SEVERITY_POINTS[r.severity] || 0;
    xp += rx;
    points += rp;
    impact += SEVERITY_IMPACT[r.severity] || 0;
    if (r.severity === 'critical') critical++;
    if (!r.xpAwarded || !r.pointsAwarded) {
      r.xpAwarded = rx;
      r.pointsAwarded = rp;
      await r.save();
    }
  }
  user.xp = xp;
  user.points = points;
  user.impactScore = impact;
  const existing = new Map((user.badges || []).map((b) => [b.name, b]));
  user.badges = badgesFor({ accepted: reports.length, critical, points }).map(
    (b) => existing.get(b.name) || { ...b, earnedAt: new Date() }
  );
  await user.save();
  return user;
}
