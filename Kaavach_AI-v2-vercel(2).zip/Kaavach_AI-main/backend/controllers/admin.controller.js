import User from '../models/User.model.js';
import Program from '../models/Program.model.js';
import Report from '../models/Report.model.js';
import { asyncHandler, isValidId, paging } from '../utils/http.js';

// GET /api/admin/users?role=&search=&page=&limit=
export const getUsers = asyncHandler(async (req, res) => {
  const { role, search } = req.query;
  const { page, limit, skip } = paging(req.query, 50, 200);
  const query = {};
  if (['hacker', 'company', 'admin'].includes(role)) query.role = role;
  if (search) {
    const rx = new RegExp(String(search).replace(/[.*+?^${}()|[\]\\]/g, '\\$&').slice(0, 80), 'i');
    query.$or = [{ name: rx }, { email: rx }, { companyName: rx }];
  }
  const [users, total] = await Promise.all([
    User.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit),
    User.countDocuments(query),
  ]);
  res.json({ users, totalPages: Math.ceil(total / limit), currentPage: page, total });
});

// PUT /api/admin/users/:id/approve  { isApproved: boolean }
export const approveCompany = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return res.status(404).json({ message: 'Company not found' });
  const user = await User.findById(req.params.id);
  if (!user || user.role !== 'company') return res.status(404).json({ message: 'Company not found' });
  user.isApproved = req.body.isApproved === true || req.body.isApproved === 'true';
  await user.save();
  if (!user.isApproved) await Program.updateMany({ createdBy: user._id }, { status: 'inactive' });
  res.json(user);
});

// DELETE /api/admin/users/:id
export const deleteUser = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return res.status(404).json({ message: 'User not found' });
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
  if (user.role === 'admin') return res.status(403).json({ message: 'Cannot delete admin user' });
  // Close the company's programs so hackers cannot submit to an orphaned program.
  if (user.role === 'company') await Program.updateMany({ createdBy: user._id }, { status: 'inactive' });
  await user.deleteOne();
  res.json({ message: 'User deleted' });
});

// GET /api/admin/stats
export const getDashboardStats = asyncHandler(async (req, res) => {
  const [totalUsers, totalHackers, totalCompanies, pendingCompanies, totalPrograms, activePrograms, totalReports, pendingReports, paid] =
    await Promise.all([
      User.countDocuments(),
      User.countDocuments({ role: 'hacker' }),
      User.countDocuments({ role: 'company' }),
      User.countDocuments({ role: 'company', isApproved: false }),
      Program.countDocuments(),
      Program.countDocuments({ status: 'active' }),
      Report.countDocuments(),
      Report.countDocuments({ status: 'pending' }),
      Report.aggregate([{ $match: { status: 'accepted' } }, { $group: { _id: null, total: { $sum: '$reward' } } }]),
    ]);
  res.json({
    totalUsers, totalHackers, totalCompanies, pendingCompanies,
    totalPrograms, activePrograms, totalReports, pendingReports,
    totalRewards: paid[0]?.total || 0,
  });
});
