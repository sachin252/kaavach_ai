import Program from '../models/Program.model.js';
import Report from '../models/Report.model.js';
import { asyncHandler, isValidId, paging, pick, toTagList } from '../utils/http.js';
import { broadcastToHackers } from '../utils/socket.js';

const SEVERITIES = ['low', 'medium', 'high', 'critical'];

const normalise = (body) => {
  const data = pick(body, ['title', 'description', 'rules', 'severityLevels', 'rewardRange', 'status', 'inScope', 'outOfScope']);
  if (data.severityLevels) data.severityLevels = toTagList(data.severityLevels).filter((s) => SEVERITIES.includes(s));
  if (data.inScope !== undefined) data.inScope = toTagList(data.inScope);
  if (data.outOfScope !== undefined) data.outOfScope = toTagList(data.outOfScope);
  if (data.rewardRange) {
    data.rewardRange = { min: Number(data.rewardRange.min) || 0, max: Number(data.rewardRange.max) || 0 };
  }
  return data;
};

const validate = (data, partial = false) => {
  if (!partial && (!data.title || !data.description || !data.rules)) return 'Title, description and rules are required';
  if (!partial && !data.severityLevels?.length) return 'Select at least one severity level';
  if (data.rewardRange) {
    const { min, max } = data.rewardRange;
    if (min < 0 || max < 0) return 'Rewards cannot be negative';
    if (max < min) return 'Maximum reward must be greater than or equal to minimum';
    if (!partial && max <= 0) return 'Maximum reward must be greater than 0';
  } else if (!partial) return 'Reward range is required';
  if (data.status && !['active', 'inactive'].includes(data.status)) return 'Invalid status';
  return null;
};

// GET /api/programs  (?severity=&status=&search=&mine=true&page=&limit=)
export const getPrograms = asyncHandler(async (req, res) => {
  const { severity, status, search, mine, createdBy } = req.query;
  const { page, limit, skip } = paging(req.query, 10, 50);
  const query = {};

  if (severity && SEVERITIES.includes(severity)) query.severityLevels = severity;
  if (status && ['active', 'inactive'].includes(status)) query.status = status;
  if (mine === 'true' && req.user) query.createdBy = req.user._id;
  else if (createdBy && isValidId(createdBy)) query.createdBy = createdBy;
  if (search) {
    const rx = new RegExp(String(search).replace(/[.*+?^${}()|[\]\\]/g, '\\$&').slice(0, 80), 'i');
    query.$or = [{ title: rx }, { description: rx }];
  }

  const [programs, total] = await Promise.all([
    Program.find(query)
      .select('-reports')
      .populate('createdBy', 'name companyName companyWebsite')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean(),
    Program.countDocuments(query),
  ]);

  // Attach live report counts
  const ids = programs.map((p) => p._id);
  const counts = await Report.aggregate([
    { $match: { program: { $in: ids } } },
    { $group: { _id: '$program', total: { $sum: 1 }, accepted: { $sum: { $cond: [{ $eq: ['$status', 'accepted'] }, 1, 0] } } } },
  ]);
  const map = Object.fromEntries(counts.map((c) => [String(c._id), c]));
  programs.forEach((p) => {
    p.reportCount = map[String(p._id)]?.total || 0;
    p.acceptedCount = map[String(p._id)]?.accepted || 0;
  });

  res.json({ programs, totalPages: Math.ceil(total / limit), currentPage: page, total });
});

// GET /api/programs/:id  -- public detail with aggregated (non-sensitive) stats
export const getProgram = asyncHandler(async (req, res) => {
  if (!isValidId(req.params.id)) return res.status(404).json({ message: 'Program not found' });
  const program = await Program.findById(req.params.id)
    .select('-reports')
    .populate('createdBy', 'name companyName companyWebsite')
    .lean();
  if (!program) return res.status(404).json({ message: 'Program not found' });

  const since = new Date();
  since.setMonth(since.getMonth() - 5, 1);
  since.setHours(0, 0, 0, 0);

  const [statusAgg, monthly, resolved, paid] = await Promise.all([
    Report.aggregate([{ $match: { program: program._id } }, { $group: { _id: '$status', count: { $sum: 1 } } }]),
    Report.aggregate([
      { $match: { program: program._id, createdAt: { $gte: since } } },
      {
        $group: {
          _id: { y: { $year: '$createdAt' }, m: { $month: '$createdAt' } },
          reports: { $sum: 1 },
          accepted: { $sum: { $cond: [{ $eq: ['$status', 'accepted'] }, 1, 0] } },
        },
      },
    ]),
    Report.aggregate([
      { $match: { program: program._id, resolvedAt: { $ne: null } } },
      { $group: { _id: null, avgHours: { $avg: { $divide: [{ $subtract: ['$resolvedAt', '$createdAt'] }, 3600000] } } } },
    ]),
    Report.aggregate([
      { $match: { program: program._id, status: 'accepted' } },
      { $group: { _id: null, total: { $sum: '$reward' }, hackers: { $addToSet: '$submittedBy' } } },
    ]),
  ]);

  const byStatus = Object.fromEntries(statusAgg.map((s) => [s._id, s.count]));
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i, 1);
    const hit = monthly.find((m) => m._id.y === d.getFullYear() && m._id.m === d.getMonth() + 1);
    months.push({ month: d.toLocaleString('en', { month: 'short' }), reports: hit?.reports || 0, accepted: hit?.accepted || 0 });
  }
  const total = statusAgg.reduce((s, x) => s + x.count, 0);

  program.stats = {
    totalReports: total,
    accepted: byStatus.accepted || 0,
    byStatus,
    acceptanceRate: total ? Math.round(((byStatus.accepted || 0) / total) * 100) : 0,
    avgResponseHours: resolved[0] ? Math.round(resolved[0].avgHours) : null,
    totalPaid: paid[0]?.total || 0,
    researchersRewarded: paid[0]?.hackers?.length || 0,
    timeline: months,
  };
  res.json(program);
});

// POST /api/programs
export const createProgram = asyncHandler(async (req, res) => {
  const data = normalise(req.body);
  const err = validate(data);
  if (err) return res.status(400).json({ message: err });

  const program = await Program.create({ ...data, createdBy: req.user._id });
  const populated = await Program.findById(program._id).populate('createdBy', 'name companyName');
  broadcastToHackers('program:new', { _id: program._id, title: program.title });
  res.status(201).json(populated);
});

const loadOwned = async (req, res) => {
  if (!isValidId(req.params.id)) {
    res.status(404).json({ message: 'Program not found' });
    return null;
  }
  const program = await Program.findById(req.params.id);
  if (!program) {
    res.status(404).json({ message: 'Program not found' });
    return null;
  }
  if (program.createdBy.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
    res.status(403).json({ message: 'Not authorized' });
    return null;
  }
  return program;
};

// PUT /api/programs/:id
export const updateProgram = asyncHandler(async (req, res) => {
  const program = await loadOwned(req, res);
  if (!program) return;
  const data = normalise(req.body);
  const err = validate({ ...data, rewardRange: data.rewardRange || program.rewardRange }, true);
  if (err) return res.status(400).json({ message: err });

  Object.assign(program, data);
  await program.save();
  const populated = await Program.findById(program._id).select('-reports').populate('createdBy', 'name companyName');
  res.json(populated);
});

// DELETE /api/programs/:id
export const deleteProgram = asyncHandler(async (req, res) => {
  const program = await loadOwned(req, res);
  if (!program) return;
  const reports = await Report.countDocuments({ program: program._id });
  if (reports > 0) {
    // Keep the audit trail: programs with reports are closed instead of deleted.
    program.status = 'inactive';
    await program.save();
    return res.json({ message: 'Program has reports, so it was closed instead of deleted', closed: true });
  }
  await program.deleteOne();
  res.json({ message: 'Program deleted' });
});
