import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import helmet from 'helmet';
import compression from 'compression';
import rateLimit from 'express-rate-limit';
import { fileURLToPath } from 'url';

import { sanitizeRequest } from './utils/http.js';
import { ensureAdmin } from './utils/bootstrap.js';
import { MAX_UPLOAD_MB } from './utils/upload.js';

import authRoutes from './routes/auth.routes.js';
import hackerRoutes from './routes/hacker.routes.js';
import companyRoutes from './routes/company.routes.js';
import adminRoutes from './routes/admin.routes.js';
import feedRoutes from './routes/feed.routes.js';
import programRoutes from './routes/program.routes.js';
import reportRoutes from './routes/report.routes.js';
import leaderboardRoutes from './routes/leaderboard.routes.js';
import analyticsRoutes from './routes/analytics.routes.js';
import leaderboardAnalyticsRoutes from './routes/leaderboardAnalytics.routes.js';
import extrasRoutes from './routes/extras.routes.js';
import gamificationRoutes from './routes/gamification.routes.js';
import notificationRoutes from './routes/notification.routes.js';
import statsRoutes from './routes/stats.routes.js';

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isProd = process.env.NODE_ENV === 'production';

// ---------- Required configuration ----------
export const MONGO_URI = process.env.MONGO_URI || process.env.MONGODB_URI;
export const configError = !MONGO_URI
  ? 'MONGO_URI is not set'
  : !process.env.JWT_SECRET || (isProd && process.env.JWT_SECRET.length < 32)
    ? 'JWT_SECRET is missing (or shorter than 32 chars in production)'
    : null;

// Cached connection, reused across serverless invocations.
let dbPromise = null;
export const connectDB = () => {
  if (configError) return Promise.reject(new Error(configError));
  if (!dbPromise) {
    dbPromise = mongoose
      .connect(MONGO_URI, { serverSelectionTimeoutMS: 10000, maxPoolSize: 10 })
      .then(async () => {
        console.log('✅ MongoDB connected');
        await ensureAdmin();
      })
      .catch((err) => {
        dbPromise = null;
        throw err;
      });
  }
  return dbPromise;
};

// Allowed browser origins (comma separated). Same-origin requests always work.
export const allowedOrigins = (process.env.CLIENT_ORIGIN || 'http://localhost:3000,http://localhost:5173')
  .split(',')
  .map((o) => o.trim())
  .filter(Boolean);
// Vercel deployment URLs are allowed automatically
for (const v of [process.env.VERCEL_URL, process.env.VERCEL_BRANCH_URL, process.env.VERCEL_PROJECT_PRODUCTION_URL]) {
  if (v) allowedOrigins.push(`https://${v}`);
}

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: true,
      directives: {
        'img-src': ["'self'", 'data:', 'https:'],
        'connect-src': ["'self'", 'ws:', 'wss:', ...allowedOrigins],
        'script-src': ["'self'"],
        'style-src': ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
        'font-src': ["'self'", 'data:', 'https://fonts.gstatic.com'],
      },
    },
    crossOriginEmbedderPolicy: false,
  })
);
app.use(compression());
app.use(
  cors({
    origin: (origin, cb) => {
      if (!origin || allowedOrigins.includes(origin) || allowedOrigins.includes('*')) return cb(null, true);
      return cb(null, false);
    },
    credentials: true,
  })
);
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(sanitizeRequest);

// ---------- Rate limits ----------
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 600, standardHeaders: true, legacyHeaders: false }));
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many attempts. Please try again in 15 minutes.' },
});
app.use('/api/auth/login', authLimiter);
app.use('/api/auth/register', authLimiter);

// ---------- API routes ----------
app.use('/api', (req, res, next) => {
  if (configError) return res.status(500).json({ message: `Server misconfigured: ${configError}` });
  connectDB().then(() => next(), (err) => {
    console.error('DB connect failed:', err.message);
    res.status(503).json({ message: 'Database unavailable. Please try again shortly.' });
  });
});

app.get('/api/health', (req, res) => {
  res.json({
    status: 'OK',
    db: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
    uptime: Math.round(process.uptime()),
  });
});

app.use('/api/auth', authRoutes);
app.use('/api/hacker', hackerRoutes);
app.use('/api/company', companyRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/feed', feedRoutes);
app.use('/api/programs', programRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api/leaderboard', leaderboardRoutes);
app.use('/api/analytics/leaderboard', leaderboardAnalyticsRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/extras', extrasRoutes);
app.use('/api/gamify', gamificationRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/stats', statsRoutes);

app.use('/api', (req, res) => res.status(404).json({ message: 'API route not found' }));

// ---------- Frontend (single-service deploy) ----------
const distDir = path.resolve(__dirname, process.env.FRONTEND_DIST || '../frontend/dist');
if (fs.existsSync(path.join(distDir, 'index.html'))) {
  app.use(express.static(distDir, { maxAge: '7d', index: false }));
  app.get('*', (req, res) => {
    res.setHeader('Cache-Control', 'no-cache');
    res.sendFile(path.join(distDir, 'index.html'));
  });
  console.log('🖥️  Serving frontend from', distDir);
}

// ---------- Error handler ----------
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  if (err.name === 'MulterError') {
    return res.status(400).json({ message: err.code === 'LIMIT_FILE_SIZE' ? `File is larger than ${MAX_UPLOAD_MB} MB` : err.message });
  }
  if (err.message === 'Only PDF and DOCX files are allowed') return res.status(400).json({ message: err.message });
  if (err.name === 'ValidationError') {
    return res.status(400).json({ message: Object.values(err.errors).map((e) => e.message).join(', ') });
  }
  if (err.name === 'CastError') return res.status(400).json({ message: `Invalid ${err.path}` });
  if (err.code === 11000) return res.status(409).json({ message: 'A record with that value already exists' });

  console.error(err);
  res.status(err.status || 500).json({
    message: isProd ? 'Something went wrong. Please try again.' : err.message,
  });
});

export default app;
