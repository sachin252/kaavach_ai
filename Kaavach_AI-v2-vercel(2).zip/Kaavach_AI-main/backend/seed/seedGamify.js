// Recalculate XP, points, impact and badges for every hacker from accepted reports.
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from '../models/User.model.js';
import { recalcUserGamification } from '../controllers/gamification.controller.js';

dotenv.config();
await mongoose.connect(process.env.MONGO_URI || process.env.MONGODB_URI);
const hackers = await User.find({ role: 'hacker' }).select('_id email');
for (const h of hackers) {
  const u = await recalcUserGamification(h._id);
  console.log(`${h.email}: xp=${u.xp} points=${u.points} level=${u.level}`);
}
await mongoose.disconnect();
