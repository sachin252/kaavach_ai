// Seeds the starter Knowledge Base articles. Safe to re-run: existing slugs are skipped.
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import User from '../models/User.model.js';
import KBArticle from '../models/KBArticle.model.js';

dotenv.config();

const ARTICLES = [
  {
    title: 'How to submit a great vulnerability report',
    slug: 'how-to-submit-a-report',
    category: 'reports',
    readTime: '4',
    summary: 'What triage teams need from you: clear steps, impact, and proof.',
    content: `## Structure\n1. **Title** that names the bug class and the affected asset.\n2. **Summary** in two or three sentences.\n3. **Steps to reproduce**, numbered, starting from a fresh session.\n4. **Impact**: what an attacker gains, in business terms.\n5. **Proof**: screenshots, request/response pairs, or a short video.\n6. **Suggested fix** if you have one.\n\nAttach your full write-up as PDF or DOCX (max 10 MB).`,
    tags: ['reports', 'triage'],
  },
  {
    title: 'Severity guide',
    slug: 'severity-guide',
    category: 'guides',
    readTime: '3',
    summary: 'How Kaavach maps findings to Low, Medium, High and Critical.',
    content: `| Severity | Typical examples |\n|---|---|\n| Critical | RCE, auth bypass on production, mass data exposure |\n| High | Stored XSS on sensitive pages, IDOR exposing PII, SSRF to internal services |\n| Medium | Reflected XSS, CSRF on state-changing actions, missing rate limits on login |\n| Low | Verbose errors, missing security headers with limited impact |\n\nCompanies make the final call and may adjust severity during triage.`,
    tags: ['cvss', 'severity'],
  },
  {
    title: 'Rules of engagement and safe harbour',
    slug: 'rules-of-engagement',
    category: 'security',
    readTime: '3',
    summary: 'Stay in scope, avoid harm, and keep findings confidential.',
    content: `- Test only assets listed **in scope** on the program page.\n- Do not access, modify or delete data that is not yours. Use your own test accounts.\n- No denial-of-service, spam, social engineering or physical testing.\n- Stop and report as soon as you confirm a vulnerability.\n- Keep findings confidential until the company approves disclosure.\n\nResearchers who follow these rules act in good faith under the program's policy.`,
    tags: ['policy', 'scope'],
  },
  {
    title: 'Launching a bug bounty program (for companies)',
    slug: 'launching-a-program',
    category: 'programs',
    readTime: '5',
    summary: 'Scope, reward ranges and triage SLAs that attract good researchers.',
    content: `1. **Define scope** precisely: domains, apps and APIs, plus explicit exclusions.\n2. **Set rewards** per severity. Competitive ranges get more attention.\n3. **Write clear rules**: testing limits, test accounts, and disclosure policy.\n4. **Commit to an SLA**: acknowledge within 2 business days, triage within 7.\n5. **Pay promptly** and share feedback; your response time is shown on the program page.`,
    tags: ['companies', 'programs'],
  },
];

const run = async () => {
  const uri = process.env.MONGO_URI || process.env.MONGODB_URI;
  await mongoose.connect(uri);
  const admin = await User.findOne({ role: 'admin' });
  if (!admin) throw new Error('Create an admin first (set ADMIN_EMAIL / ADMIN_PASSWORD and start the server).');
  for (const a of ARTICLES) {
    if (await KBArticle.exists({ slug: a.slug })) continue;
    await KBArticle.create({ ...a, author: admin._id });
    console.log('➕', a.title);
  }
  console.log('✅ Knowledge base seeded');
  await mongoose.disconnect();
};

run().catch((e) => {
  console.error('❌', e.message);
  process.exit(1);
});
