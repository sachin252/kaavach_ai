import multer from 'multer';
import path from 'path';
import crypto from 'crypto';
import fs from 'fs';
import { fileURLToPath } from 'url';
import mongoose from 'mongoose';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Legacy disk folder (files uploaded before attachments moved into MongoDB).
export const uploadsDir = path.resolve(process.env.UPLOAD_DIR || path.join(__dirname, '../uploads'));

// Vercel functions accept request bodies up to ~4.5 MB, so the limit is lower there.
export const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB) || (process.env.VERCEL ? 4 : 10);

const ALLOWED = {
  '.pdf': ['application/pdf'],
  '.docx': ['application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/octet-stream'],
  '.doc': ['application/msword', 'application/octet-stream'],
};

const fileFilter = (req, file, cb) => {
  const ext = path.extname(file.originalname).toLowerCase();
  if (ALLOWED[ext] && ALLOWED[ext].includes(file.mimetype)) cb(null, true);
  else cb(new Error('Only PDF and DOCX files are allowed'), false);
};

// Files are held in memory, then streamed into MongoDB GridFS. No local disk is
// needed, so the same code runs on serverless hosts and on normal servers.
export const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 },
  fileFilter,
});

const bucket = () => new mongoose.mongo.GridFSBucket(mongoose.connection.db, { bucketName: 'attachments' });

const MAGIC = { '.pdf': '%PDF', '.docx': 'PK', '.doc': '\xD0\xCF' };

// Stores the uploaded file and returns a reference like "gridfs:<id>".
export async function saveUpload(file, meta = {}) {
  const ext = path.extname(file.originalname).toLowerCase();
  const head = file.buffer.subarray(0, 4).toString('latin1');
  if (MAGIC[ext] && !head.startsWith(MAGIC[ext])) {
    const err = new Error('Only PDF and DOCX files are allowed');
    throw err;
  }
  const name = `report-${Date.now()}-${crypto.randomBytes(8).toString('hex')}${ext}`;
  return new Promise((resolve, reject) => {
    const stream = bucket().openUploadStream(name, { metadata: { ...meta, originalName: file.originalname, contentType: file.mimetype } });
    stream.on('error', reject);
    stream.on('finish', () => resolve(`gridfs:${stream.id.toString()}`));
    stream.end(file.buffer);
  });
}

export async function deleteUpload(ref) {
  if (!ref?.startsWith('gridfs:')) return;
  try {
    await bucket().delete(new mongoose.Types.ObjectId(ref.slice(7)));
  } catch {
    /* already gone */
  }
}

// Returns a readable stream for a stored reference, or null when missing.
export async function openUpload(ref) {
  if (ref?.startsWith('gridfs:')) {
    const id = ref.slice(7);
    if (!mongoose.Types.ObjectId.isValid(id)) return null;
    const files = await bucket().find({ _id: new mongoose.Types.ObjectId(id) }).limit(1).toArray();
    if (!files.length) return null;
    return { stream: bucket().openDownloadStream(files[0]._id), length: files[0].length, contentType: files[0].metadata?.contentType };
  }
  // Legacy disk file
  const stored = path.basename(ref || '');
  const filePath = path.join(uploadsDir, stored);
  if (!stored || !filePath.startsWith(uploadsDir) || !fs.existsSync(filePath)) return null;
  return { stream: fs.createReadStream(filePath), length: fs.statSync(filePath).size };
}
