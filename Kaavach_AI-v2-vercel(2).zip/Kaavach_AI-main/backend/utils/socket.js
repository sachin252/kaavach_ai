import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';

let io;

// Socket clients must present their JWT; they are joined only to their own room.
export function initSocket(server, origins = []) {
  io = new Server(server, {
    cors: { origin: origins.length ? origins : true, methods: ['GET', 'POST'], credentials: true },
  });

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(); // anonymous sockets get no private rooms
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      socket.data.userId = decoded.id;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  io.on('connection', (socket) => {
    if (socket.data.userId) socket.join(`user:${socket.data.userId}`);
    socket.on('joinAllHackersRoom', () => socket.join('hackers'));
  });

  console.log('✅ Socket.IO initialized');
  return io;
}

export function getIO() {
  if (!io) throw new Error('Socket.io not initialized');
  return io;
}

export function emitNotificationToUser(userId, payload) {
  if (!io) return;
  io.to(`user:${userId}`).emit('notification', payload);
}

export function broadcastToHackers(event, payload) {
  if (!io) return;
  io.to('hackers').emit(event, payload);
}
