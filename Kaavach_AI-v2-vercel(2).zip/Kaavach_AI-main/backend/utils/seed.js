import mongoose from 'mongoose';
import dotenv from 'dotenv';
import { ensureAdmin } from './bootstrap.js';

dotenv.config();

const run = async () => {
  const uri = process.env.MONGO_URI || process.env.MONGODB_URI;
  if (!uri) throw new Error('MONGO_URI is not set');
  if (!process.env.ADMIN_EMAIL) process.env.ADMIN_EMAIL = 'admin@kaavach.ai';
  if (!process.env.ADMIN_PASSWORD) {
    throw new Error('Set ADMIN_PASSWORD (min 10 chars) before running the seed.');
  }
  await mongoose.connect(uri);
  await ensureAdmin();
  console.log('Done.');
  await mongoose.disconnect();
};

run().catch((e) => {
  console.error('❌', e.message);
  process.exit(1);
});
