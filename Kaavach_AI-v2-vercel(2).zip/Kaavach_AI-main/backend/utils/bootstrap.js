import User from '../models/User.model.js';

// Creates the first admin account from ADMIN_EMAIL / ADMIN_PASSWORD on boot,
// so a fresh production deploy never ships with a hard-coded password.
export const ensureAdmin = async () => {
  const exists = await User.exists({ role: 'admin' });
  if (exists) return;

  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password) {
    console.warn('⚠️  No admin account exists. Set ADMIN_EMAIL and ADMIN_PASSWORD to create one on next start.');
    return;
  }
  if (password.length < 10) {
    console.warn('⚠️  ADMIN_PASSWORD must be at least 10 characters. Admin not created.');
    return;
  }
  await User.create({
    name: process.env.ADMIN_NAME || 'Platform Admin',
    email,
    password,
    role: 'admin',
    isEmailVerified: true,
    isApproved: true,
  });
  console.log(`👑 Admin account created for ${email}`);
};
