/**
 * XP rules per accepted report severity, and level/tier progression.
 * Level L starts at 100 * (L-1)^2 XP:  L1 = 0, L2 = 100, L3 = 400, L4 = 900 ...
 */
export const SEVERITY_XP = {
  critical: Number(process.env.XP_CRITICAL) || 500,
  high: Number(process.env.XP_HIGH) || 300,
  medium: Number(process.env.XP_MEDIUM) || 150,
  low: Number(process.env.XP_LOW) || 50,
};

export const SEVERITY_POINTS = { low: 10, medium: 25, high: 50, critical: 100 };
export const SEVERITY_IMPACT = { low: 5, medium: 15, high: 30, critical: 50 };

export function xpForSeverity(severity) {
  return SEVERITY_XP[severity?.toLowerCase()] || 0;
}

export function requiredXpForLevel(level) {
  return 100 * Math.max(0, level - 1) ** 2;
}

export function levelFromXp(xp) {
  if (!xp || xp <= 0) return 1;
  return Math.floor(Math.sqrt(xp / 100)) + 1;
}

export function tierFromLevel(level) {
  if (level >= 13) return 'Diamond';
  if (level >= 10) return 'Platinum';
  if (level >= 7) return 'Gold';
  if (level >= 4) return 'Silver';
  return 'Bronze';
}

export function levelProgress(xp) {
  const currentLevel = levelFromXp(xp);
  const currentLevelXp = requiredXpForLevel(currentLevel);
  const nextLevelXp = requiredXpForLevel(currentLevel + 1);
  const progress = Math.max(0, Math.min(1, (xp - currentLevelXp) / (nextLevelXp - currentLevelXp)));
  return { currentLevel, progress, nextLevelXp, currentLevelXp };
}

// Badge rules evaluated from a hacker's accepted-report history.
export function badgesFor({ accepted = 0, critical = 0, points = 0 }) {
  const out = [];
  if (accepted >= 1) out.push({ name: 'First Blood', icon: 'bug' });
  if (accepted >= 5) out.push({ name: 'Professional', icon: 'shield' });
  if (accepted >= 10) out.push({ name: 'Expert', icon: 'award' });
  if (critical >= 1) out.push({ name: 'Critical Finder', icon: 'flame' });
  if (points >= 200) out.push({ name: 'Master', icon: 'star' });
  if (points >= 500) out.push({ name: 'Elite', icon: 'crown' });
  return out;
}
