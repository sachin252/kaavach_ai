import mongoose from 'mongoose';

// Wrap async route handlers so rejected promises reach the error middleware
// instead of hanging the request or crashing the process.
export const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

export const isValidId = (id) => mongoose.Types.ObjectId.isValid(id);

// Strip keys that start with "$" or contain "." to block NoSQL operator injection.
const clean = (value) => {
  if (Array.isArray(value)) return value.map(clean);
  if (value && typeof value === 'object' && !(value instanceof Date)) {
    for (const key of Object.keys(value)) {
      if (key.startsWith('$') || key.includes('.')) delete value[key];
      else value[key] = clean(value[key]);
    }
  }
  return value;
};

export const sanitizeRequest = (req, _res, next) => {
  if (req.body) clean(req.body);
  if (req.params) clean(req.params);
  if (req.query) {
    for (const key of Object.keys(req.query)) {
      if (key.startsWith('$')) delete req.query[key];
      else if (typeof req.query[key] === 'object') req.query[key] = String(req.query[key]);
    }
  }
  next();
};

// Pick only the listed keys from an object (mass-assignment guard).
export const pick = (obj = {}, keys = []) =>
  keys.reduce((acc, k) => {
    if (obj[k] !== undefined) acc[k] = obj[k];
    return acc;
  }, {});

export const toTagList = (v) => {
  if (Array.isArray(v)) return v.map((t) => String(t).trim()).filter(Boolean).slice(0, 20);
  if (typeof v === 'string') return v.split(',').map((t) => t.trim()).filter(Boolean).slice(0, 20);
  return [];
};

export const paging = (query, defLimit = 20, maxLimit = 100) => {
  const page = Math.max(1, parseInt(query.page, 10) || 1);
  const limit = Math.min(maxLimit, Math.max(1, parseInt(query.limit, 10) || defLimit));
  return { page, limit, skip: (page - 1) * limit };
};
