import express from 'express';
import { getPrograms, getProgram, createProgram, updateProgram, deleteProgram } from '../controllers/program.controller.js';
import { protect, optionalAuth, isApprovedCompanyOrAdmin, isCompanyOrAdmin } from '../middleware/auth.middleware.js';

const router = express.Router();

router.get('/', optionalAuth, getPrograms);
router.get('/:id', getProgram);
router.post('/', protect, isApprovedCompanyOrAdmin, createProgram);
router.put('/:id', protect, isCompanyOrAdmin, updateProgram);
router.delete('/:id', protect, isCompanyOrAdmin, deleteProgram);

export default router;
