import express from 'express';
import { protect, isCompany } from '../middleware/auth.middleware.js';
import { getCompanyRewardSummary } from '../controllers/analytics.controller.js';

const router = express.Router();
router.get('/dashboard', protect, isCompany, getCompanyRewardSummary);
export default router;
