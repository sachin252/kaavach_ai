import express from 'express';
import * as c from '../controllers/extras.controller.js';
import { protect, isAdmin, isApprovedCompanyOrAdmin } from '../middleware/auth.middleware.js';

const router = express.Router();

// Marketplace: any signed-in user can list an item
router.get('/marketplace', c.listMarketplace);
router.get('/marketplace/:id', c.getMarketplaceItem);
router.post('/marketplace', protect, c.createMarketplaceItem);
router.delete('/marketplace/:id', protect, c.deleteMarketplaceItem);

// Writeups: any signed-in user can publish
router.get('/writeups', c.listWriteups);
router.get('/writeups/:id', c.getWriteup);
router.post('/writeups', protect, c.createWriteup);
router.delete('/writeups/:id', protect, c.deleteWriteup);

// Jobs: approved companies and admins
router.get('/jobs', c.listJobs);
router.get('/jobs/:id', c.getJob);
router.post('/jobs', protect, isApprovedCompanyOrAdmin, c.createJob);
router.delete('/jobs/:id', protect, c.deleteJob);

// Knowledge base: official content, admin only
router.get('/kb', c.listKB);
router.get('/kb/:slug', c.getKBArticle);
router.post('/kb', protect, isAdmin, c.createKBArticle);
router.delete('/kb/:id', protect, isAdmin, c.deleteKBArticle);

// Breach alerts: admin only
router.get('/breach-alerts', c.listBreachAlerts);
router.post('/breach-alerts', protect, isAdmin, c.createBreachAlert);
router.delete('/breach-alerts/:id', protect, isAdmin, c.deleteBreachAlert);

export default router;
