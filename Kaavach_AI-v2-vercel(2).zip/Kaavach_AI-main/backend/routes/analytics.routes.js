import express from "express";
import { protect, authorizeRoles } from "../middleware/auth.middleware.js";
import { getGlobalLeaderboard, getSeasonalLeaderboard } from "../controllers/leaderboardAnalytics.controller.js";

import {
  // Hacker analytics
  getHackerSeverityStats,
  getHackerMonthlyActivity,
  getHackerAcceptanceStats,
  getHackerImpactScore,
  getHackerSummary,

  // Company analytics
  getCompanyReportFunnel,
  getCompanyRewardSummary,
  getCompanyTTR,
  getCompanyProgramInsights,

  // Admin analytics
  getAdminOverview,
  getAbuseDetection,

} from "../controllers/analytics.controller.js";

const router = express.Router();

/* ─────────────────────────────
    ⭐ HACKER ANALYTICS
────────────────────────────── */
router.get("/hacker/severity", protect, authorizeRoles("hacker"), getHackerSeverityStats);
router.get("/hacker/monthly", protect, authorizeRoles("hacker"), getHackerMonthlyActivity);
router.get("/hacker/acceptance", protect, authorizeRoles("hacker"), getHackerAcceptanceStats);
router.get("/hacker/impact", protect, authorizeRoles("hacker"), getHackerImpactScore);
router.get("/hacker/summary", protect, authorizeRoles("hacker"), getHackerSummary);

/* ─────────────────────────────
    ⭐ COMPANY ANALYTICS
────────────────────────────── */
router.get("/company/funnel", protect, authorizeRoles("company", "admin"), getCompanyReportFunnel);
router.get("/company/rewards", protect, authorizeRoles("company", "admin"), getCompanyRewardSummary);
router.get("/company/ttr", protect, authorizeRoles("company", "admin"), getCompanyTTR);
router.get("/company/program-insights", protect, authorizeRoles("company", "admin"), getCompanyProgramInsights);

/* ─────────────────────────────
    ⭐ ADMIN ANALYTICS
────────────────────────────── */
router.get(
  "/admin/overview",
  protect,
  authorizeRoles(["admin"]),
  getAdminOverview
);

router.get(
  "/admin/abuse",
  protect,
  authorizeRoles(["admin"]),
  getAbuseDetection
);

/* ─────────────────────────────
    ⭐ LEADERBOARDS
────────────────────────────── */
router.get("/leaderboard/seasonal", getSeasonalLeaderboard);
router.get("/leaderboard/global", getGlobalLeaderboard);

export default router;
