import express from 'express';
import { protect, isHacker } from '../middleware/auth.middleware.js';
import { getMyStats } from '../controllers/leaderboard.controller.js';

const router = express.Router();
router.get('/dashboard', protect, isHacker, getMyStats);
export default router;
