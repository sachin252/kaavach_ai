import jwt from 'jsonwebtoken';
import User from '../models/User.model.js';

const readToken = (req) => {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : null;
};

export const protect = async (req, res, next) => {
  const token = readToken(req);
  if (!token) return res.status(401).json({ message: 'Not authorized, no token' });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id);
    if (!req.user) return res.status(401).json({ message: 'User not found' });
    next();
  } catch {
    return res.status(401).json({ message: 'Not authorized, token failed' });
  }
};

// Attaches req.user when a valid token is present, but never blocks.
export const optionalAuth = async (req, _res, next) => {
  const token = readToken(req);
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id);
    } catch {
      /* ignore */
    }
  }
  next();
};

const roleGuard = (check, message) => (req, res, next) =>
  req.user && check(req.user) ? next() : res.status(403).json({ message });

export const isHacker = roleGuard((u) => u.role === 'hacker', 'Access denied. Hacker role required.');
export const isCompany = roleGuard((u) => u.role === 'company', 'Access denied. Company role required.');
export const isAdmin = roleGuard((u) => u.role === 'admin', 'Access denied. Admin role required.');
export const isCompanyOrAdmin = roleGuard(
  (u) => u.role === 'admin' || u.role === 'company',
  'Access denied. Company or Admin role required.'
);
// Companies must be approved by an admin before they can publish programs/jobs.
export const isApprovedCompanyOrAdmin = roleGuard(
  (u) => u.role === 'admin' || (u.role === 'company' && u.isApproved),
  'Only approved company accounts can do this.'
);

// Accepts authorizeRoles('admin', 'company') or authorizeRoles(['admin']).
export const authorizeRoles = (...roles) => {
  const allowed = roles.flat();
  return (req, res, next) => {
    if (!req.user || !allowed.includes(req.user.role)) {
      return res.status(403).json({ message: 'You are not allowed to access this resource' });
    }
    next();
  };
};
