import http from 'http';
import mongoose from 'mongoose';
import app, { connectDB, configError, allowedOrigins } from './app.js';
import { initSocket } from './utils/socket.js';

if (configError) {
  console.error(`❌ ${configError}`);
  process.exit(1);
}

const PORT = process.env.PORT || 5000;
const server = http.createServer(app);

const start = async () => {
  try {
    await connectDB();
    initSocket(server, allowedOrigins);
    server.listen(PORT, () => console.log(`🚀 KAAVACH AI running on port ${PORT}`));
  } catch (error) {
    console.error('❌ Startup failed:', error.message);
    process.exit(1);
  }
};

const shutdown = (signal) => {
  console.log(`${signal} received, shutting down`);
  server.close(() => mongoose.connection.close(false).then(() => process.exit(0)));
  setTimeout(() => process.exit(1), 10000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

start();
