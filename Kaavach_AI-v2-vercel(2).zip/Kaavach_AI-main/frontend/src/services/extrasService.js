import api from "./api";

export const extrasService = {
  listMarketplace: (params) => api.get("/extras/marketplace", { params }),
  getMarketplaceItem: (id) => api.get(`/extras/marketplace/${id}`),
  createMarketplaceItem: (data) => api.post("/extras/marketplace", data),
  deleteMarketplaceItem: (id) => api.delete(`/extras/marketplace/${id}`),

  listWriteups: (params) => api.get("/extras/writeups", { params }),
  getWriteup: (id) => api.get(`/extras/writeups/${id}`),
  createWriteup: (data) => api.post("/extras/writeups", data),
  deleteWriteup: (id) => api.delete(`/extras/writeups/${id}`),

  listJobs: (params) => api.get("/extras/jobs", { params }),
  getJob: (id) => api.get(`/extras/jobs/${id}`),
  createJob: (data) => api.post("/extras/jobs", data),
  deleteJob: (id) => api.delete(`/extras/jobs/${id}`),

  listKB: (params) => api.get("/extras/kb", { params }),
  getKBArticle: (slug) => api.get(`/extras/kb/${slug}`),
  createKBArticle: (data) => api.post("/extras/kb", data),
  deleteKBArticle: (id) => api.delete(`/extras/kb/${id}`),

  listBreachAlerts: () => api.get("/extras/breach-alerts"),
  createBreachAlert: (data) => api.post("/extras/breach-alerts", data),
  deleteBreachAlert: (id) => api.delete(`/extras/breach-alerts/${id}`),
};
