import api from "./api";

export const statsService = {
  getPublicStats: async () => (await api.get("/stats/public")).data,
};
