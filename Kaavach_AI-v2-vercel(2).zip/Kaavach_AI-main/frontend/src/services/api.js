import axios from "axios";
import toast from "react-hot-toast";

// Same-origin "/api" by default (single-service deploy). Set VITE_API_URL only
// when the API lives on a different domain.
export const API_URL = import.meta.env.VITE_API_URL || "/api";

const api = axios.create({ baseURL: API_URL, timeout: 30000 });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

let redirecting = false;
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;
    const hadToken = !!localStorage.getItem("token");

    if (status === 401) {
      if (hadToken && !redirecting) {
        redirecting = true;
        toast.error("Session expired. Please log in again.");
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        setTimeout(() => (window.location.href = "/login"), 600);
      } else if (!hadToken && !error.config?.url?.includes("/auth/")) {
        toast.error("Please log in to continue.");
      }
    } else if (status === 403) {
      toast.error(error.response?.data?.message || "You are not allowed to perform this action.");
    } else if (status === 429) {
      toast.error(error.response?.data?.message || "Too many requests. Please slow down.");
    } else if (!error.response) {
      toast.error("Network error. Check your connection.");
    }
    return Promise.reject(error);
  }
);

export const errorMessage = (err, fallback = "Something went wrong") =>
  err?.response?.data?.message || fallback;

export default api;
