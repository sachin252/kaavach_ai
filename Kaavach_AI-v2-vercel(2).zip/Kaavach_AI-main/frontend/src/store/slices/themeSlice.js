import { createSlice } from '@reduxjs/toolkit'

const getInitialTheme = () => {
  if (typeof window === 'undefined') return 'dark'
  const savedTheme = localStorage.getItem('theme')
  const resolved = 'dark' // product ships dark-only; light palette is not complete
  document.documentElement.classList.toggle('dark', resolved === 'dark')
  return resolved
}

const themeSlice = createSlice({
  name: 'theme',
  initialState: {
    theme: getInitialTheme(),
  },
  reducers: {
    toggleTheme: (state) => {
      state.theme = 'dark'
      localStorage.setItem('theme', state.theme)
      document.documentElement.classList.toggle('dark', state.theme === 'dark')
    },
    setTheme: (state, action) => {
      state.theme = 'dark'
      document.documentElement.classList.add('dark')
    },
  },
})

export const { toggleTheme, setTheme } = themeSlice.actions
export default themeSlice.reducer

