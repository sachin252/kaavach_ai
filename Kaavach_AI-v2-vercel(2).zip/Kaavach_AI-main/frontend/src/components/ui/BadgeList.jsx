import { badgeName } from "@/lib/format"

const BadgeList = ({ badges = [] }) =>
  badges.length === 0 ? (
    <p className="text-sm text-muted-foreground">No badges yet. Get your first report accepted to earn one.</p>
  ) : (
    <div className="flex flex-wrap gap-2">
      {badges.map((b, i) => (
        <div key={i} className="rounded-full bg-gradient-to-r from-blue-600 to-indigo-600 px-3 py-1 text-sm text-white">
          {badgeName(b)}
        </div>
      ))}
    </div>
  )

export default BadgeList
