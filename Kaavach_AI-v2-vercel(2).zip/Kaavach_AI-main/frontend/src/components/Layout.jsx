import { Outlet, useLocation } from "react-router-dom"
import { useSelector, useDispatch } from "react-redux"
import { Suspense, useEffect, useMemo, useState } from "react"
import {
  ActivitySquare,
  Bell,
  BookOpen,
  Briefcase,
  Bug,
  Building2,
  Compass,
  FileText,
  Home,
  Layers,
  LineChart,
  ShieldAlert,
  ShoppingBag,
  Shield,
  UsersRound,
  X,
} from "lucide-react"

import { Sidebar } from "@/components/ui/sidebar"
import { Navbar } from "@/components/ui/navbar"
import { toggleTheme } from "@/store/slices/themeSlice"

const PageLoader = () => (
  <div className="flex justify-center py-16">
    <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
  </div>
)

const Layout = () => {
  const { user } = useSelector((state) => state.auth)
  const { theme } = useSelector((state) => state.theme)
  const dispatch = useDispatch()
  const location = useLocation()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark")
  }, [theme])

  // Close the mobile menu and scroll to top on navigation
  useEffect(() => {
    setSidebarOpen(false)
    window.scrollTo(0, 0)
  }, [location.pathname])

  const navSections = useMemo(() => {
    const role = user?.role
    const sections = [
      {
        label: "Explore",
        items: [
          { label: "Home", to: "/", icon: Home },
          { label: "Programs", to: "/programs", icon: Compass },
          { label: "Feed", to: "/feed", icon: Layers },
          { label: "Leaderboard", to: "/leaderboard", icon: LineChart },
        ],
      },
      {
        label: "Workspace",
        items: [
          role === "hacker" && { label: "Hacker HQ", to: "/dashboard/hacker", icon: Bug },
          role === "company" && { label: "Company Ops", to: "/dashboard/company", icon: Building2 },
          role === "admin" && { label: "Admin Command", to: "/dashboard/admin", icon: Shield },
          role === "hacker" && { label: "My Analytics", to: "/analytics/hacker", icon: ActivitySquare },
          role === "company" && { label: "Company Analytics", to: "/analytics/company", icon: LineChart },
          role === "admin" && { label: "Platform Analytics", to: "/analytics/admin", icon: LineChart },
          user && { label: "Notifications", to: "/notifications", icon: Bell },
          user && { label: "My Profile", to: "/profile", icon: UsersRound },
        ].filter(Boolean),
      },
      {
        label: "Intelligence",
        items: [
          { label: "Knowledge Base", to: "/kb", icon: BookOpen },
          { label: "Writeups", to: "/writeups", icon: FileText },
          { label: "Marketplace", to: "/marketplace", icon: ShoppingBag },
          { label: "Job Board", to: "/jobs", icon: Briefcase },
          { label: "Breach Alerts", to: "/breach-alerts", icon: ShieldAlert },
        ],
      },
    ]
    return sections.filter((s) => s.items.length > 0)
  }, [user])

  return (
    <div className="relative flex min-h-screen bg-[#020617] text-foreground">
      <Sidebar sections={navSections} className="hidden lg:flex sticky top-0 h-screen shrink-0" />

      <div className="flex min-w-0 w-full flex-col">
        <Navbar
          profile={user}
          onToggleSidebar={() => setSidebarOpen(true)}
          onToggleTheme={() => dispatch(toggleTheme())}
          theme={theme}
        />

        <main className="flex-1 px-4 py-6 md:px-8">
          <div className="mx-auto flex max-w-[1440px] flex-col gap-6">
            <section className="rounded-3xl border border-white/5 bg-white/5 p-4 md:p-6 min-h-[400px]">
              <Suspense fallback={<PageLoader />}>
                <Outlet />
              </Suspense>
            </section>
          </div>
        </main>

        <footer className="border-t border-white/5 px-8 py-5 text-xs text-muted-foreground flex flex-wrap gap-4 justify-between">
          <span>© {new Date().getFullYear()} Kaavach AI. All rights reserved.</span>
          <span className="flex gap-4">
            <a href="/kb/rules-of-engagement" className="hover:text-white">Rules of engagement</a>
            <a href="/kb/severity-guide" className="hover:text-white">Severity guide</a>
            <a href="/kb" className="hover:text-white">Help</a>
          </span>
        </footer>
      </div>

      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button className="absolute inset-0 bg-black/70" aria-label="Close menu" onClick={() => setSidebarOpen(false)} />
          <div className="absolute inset-y-0 left-0 w-72 bg-[#020617]">
            <button
              className="absolute right-3 top-6 z-10 rounded-lg p-1 text-muted-foreground hover:bg-white/10"
              aria-label="Close menu"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </button>
            <Sidebar sections={navSections} className="h-full" />
          </div>
        </div>
      )}
    </div>
  )
}

export default Layout
