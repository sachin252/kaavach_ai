import { useEffect, useMemo, useState } from "react"
import toast from "react-hot-toast"
import { Upload, X } from "lucide-react"
import { reportService } from "@/services/reportService"
import { programService } from "@/services/programService"
import { errorMessage } from "@/services/api"

const SEVERITIES = ["low", "medium", "high", "critical"]
const MAX_MB = Number(import.meta.env.VITE_MAX_UPLOAD_MB) || 10

export default function SubmitReportModal({ programs: initialPrograms = [], defaultProgram = "", onClose, onSubmitted }) {
  const [extra, setExtra] = useState(null)
  const programs = useMemo(() => (extra ? [extra, ...initialPrograms] : initialPrograms), [extra, initialPrograms])

  // Deep link to a program that is not in the preloaded list
  useEffect(() => {
    if (defaultProgram && !initialPrograms.some((p) => p._id === defaultProgram)) {
      programService.getProgram(defaultProgram).then((p) => p.status === "active" && setExtra(p)).catch(() => {})
    }
  }, [defaultProgram, initialPrograms])

  const [data, setData] = useState({ program: defaultProgram, title: "", description: "", severity: "", file: null })
  const [saving, setSaving] = useState(false)

  const selected = useMemo(() => programs.find((p) => p._id === data.program), [programs, data.program])
  const allowed = selected?.severityLevels?.length ? selected.severityLevels : SEVERITIES

  useEffect(() => {
    if (!allowed.includes(data.severity)) setData((d) => ({ ...d, severity: allowed[0] || "" }))
  }, [allowed]) // eslint-disable-line react-hooks/exhaustive-deps

  const submit = async (e) => {
    e.preventDefault()
    if (!data.file) return toast.error("Please attach your report (PDF or DOCX)")
    if (data.file.size > MAX_MB * 1024 * 1024) return toast.error(`File must be under ${MAX_MB} MB`)
    try {
      setSaving(true)
      const fd = new FormData()
      Object.entries(data).forEach(([k, v]) => fd.append(k, v))
      await reportService.submitReport(fd)
      toast.success("Report submitted. The company has been notified.")
      onSubmitted?.()
      onClose()
    } catch (err) {
      toast.error(errorMessage(err, "Failed to submit report"))
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="modal-backdrop">
      <div className="modal-panel">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-cyan-300">Submit vulnerability report</h2>
          <button onClick={onClose} className="rounded-xl p-2 hover:bg-white/10" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <label className="block text-sm">
            Program
            <select required className="input-field" value={data.program} onChange={(e) => setData({ ...data, program: e.target.value })}>
              <option value="">Select a program</option>
              {programs.map((p) => (
                <option key={p._id} value={p._id}>
                  {p.title} {p.createdBy?.companyName ? `— ${p.createdBy.companyName}` : ""}
                </option>
              ))}
            </select>
          </label>

          <label className="block text-sm">
            Title
            <input required maxLength={200} className="input-field" placeholder="e.g. Stored XSS in profile bio on app.example.com"
              value={data.title} onChange={(e) => setData({ ...data, title: e.target.value })} />
          </label>

          <label className="block text-sm">
            Summary, steps to reproduce & impact
            <textarea required rows={6} className="input-field" value={data.description}
              onChange={(e) => setData({ ...data, description: e.target.value })} />
          </label>

          <label className="block text-sm">
            Severity
            <select required className="input-field capitalize" value={data.severity} onChange={(e) => setData({ ...data, severity: e.target.value })}>
              {allowed.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </label>

          <label className="block text-sm">
            Full report (PDF / DOCX, max {MAX_MB} MB)
            <input required type="file" accept=".pdf,.doc,.docx" className="input-field file:mr-3 file:rounded-lg file:border-0 file:bg-cyan-500/20 file:px-3 file:py-1 file:text-cyan-200"
              onChange={(e) => setData({ ...data, file: e.target.files?.[0] || null })} />
          </label>

          <div className="flex justify-end gap-3 pt-2">
            <button type="button" className="btn-secondary" onClick={onClose}>Cancel</button>
            <button type="submit" className="btn-primary" disabled={saving}>
              <Upload className="h-4 w-4" /> {saving ? "Submitting…" : "Submit report"}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
