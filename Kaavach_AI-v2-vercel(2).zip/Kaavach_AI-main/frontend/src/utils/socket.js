import { io } from "socket.io-client";

let socket = null;

// Connects to the API host (same origin by default) and authenticates with the JWT.
// Serverless hosts (Vercel) cannot keep WebSockets open; the UI falls back to polling.
export const realtimeEnabled = import.meta.env.VITE_DISABLE_SOCKET !== "true";

export function initSocket() {
  if (!realtimeEnabled) return null;
  if (socket) return socket;
  const url = import.meta.env.VITE_SOCKET_URL || window.location.origin;
  socket = io(url, {
    transports: ["websocket", "polling"],
    auth: { token: localStorage.getItem("token") },
  });
  return socket;
}

export function getSocket() {
  return socket;
}

export function closeSocket() {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
}
