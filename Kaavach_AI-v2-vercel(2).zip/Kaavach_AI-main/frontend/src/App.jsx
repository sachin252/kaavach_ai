import { lazy, Suspense, useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { setUser, logout } from "./store/slices/authSlice";
import { setTheme } from "./store/slices/themeSlice";
import { authService } from "./services/authService";

import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Home from "./pages/Home";

// Code-split everything behind the landing/auth pages
const HackerDashboard = lazy(() => import("./pages/dashboards/HackerDashboard"));
const CompanyDashboard = lazy(() => import("./pages/dashboards/CompanyDashboard"));
const AdminDashboard = lazy(() => import("./pages/dashboards/AdminDashboard"));
const Programs = lazy(() => import("./pages/Programs"));
const ProgramDetail = lazy(() => import("./pages/ProgramDetail"));
const Leaderboard = lazy(() => import("./pages/Leaderboard"));
const Feed = lazy(() => import("./pages/Feed"));
const Profile = lazy(() => import("./pages/Profile"));
const Notifications = lazy(() => import("./pages/Notifications"));
const Marketplace = lazy(() => import("./pages/Marketplace"));
const Writeups = lazy(() => import("./pages/Writeups"));
const JobBoard = lazy(() => import("./pages/JobBoard"));
const KnowledgeBase = lazy(() => import("./pages/KnowledgeBase"));
const BreachAlerts = lazy(() => import("./pages/BreachAlerts"));
const MarketplaceDetail = lazy(() => import("./pages/details/MarketplaceDetail"));
const WriteupDetail = lazy(() => import("./pages/details/WriteupDetail"));
const JobDetail = lazy(() => import("./pages/details/JobDetail"));
const KBArticleDetail = lazy(() => import("./pages/details/KBArticleDetail"));
const HackerAnalytics = lazy(() => import("./pages/analytics/HackerAnalytics"));
const CompanyAnalytics = lazy(() => import("./pages/analytics/CompanyAnalytics"));
const AdminAnalytics = lazy(() => import("./pages/analytics/AdminAnalytics"));

const Loader = () => (
  <div className="flex justify-center py-16">
    <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
  </div>
);

const dashboardFor = (user) =>
  !user ? "/login" : { hacker: "/dashboard/hacker", company: "/dashboard/company", admin: "/dashboard/admin" }[user.role] || "/";

const guard = (roles, el) => <ProtectedRoute allowedRoles={roles}>{el}</ProtectedRoute>;

function App() {
  const dispatch = useDispatch();
  const { token, user } = useSelector((state) => state.auth);

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") || "dark";
    dispatch(setTheme(savedTheme));
    document.documentElement.classList.toggle("dark", savedTheme === "dark");
  }, [dispatch]);

  // Refresh the signed-in user once per load so XP, level and badges are current
  useEffect(() => {
    if (!token) return;
    authService
      .getMe()
      .then((userData) => dispatch(setUser(userData)))
      .catch((err) => {
        if (err.response?.status === 401) dispatch(logout());
      });
  }, [dispatch, token]);

  return (
    <Suspense fallback={<Loader />}>
      <Routes>
        <Route path="/login" element={!token ? <Login /> : <Navigate to={dashboardFor(user)} />} />
        <Route path="/register" element={!token ? <Register /> : <Navigate to={dashboardFor(user)} />} />

        <Route element={<Layout />}>
          <Route index element={<Home />} />

          <Route path="/programs" element={<Programs />} />
          <Route path="/programs/:id" element={<ProgramDetail />} />
          <Route path="/leaderboard" element={<Leaderboard />} />
          <Route path="/feed" element={<Feed />} />

          <Route path="/marketplace" element={<Marketplace />} />
          <Route path="/marketplace/:id" element={<MarketplaceDetail />} />
          <Route path="/writeups" element={<Writeups />} />
          <Route path="/writeups/:id" element={<WriteupDetail />} />
          <Route path="/jobs" element={<JobBoard />} />
          <Route path="/jobs/:id" element={<JobDetail />} />
          <Route path="/kb" element={<KnowledgeBase />} />
          <Route path="/kb/:slug" element={<KBArticleDetail />} />
          <Route path="/breach-alerts" element={<BreachAlerts />} />

          <Route path="/analytics/hacker" element={guard(["hacker"], <HackerAnalytics />)} />
          <Route path="/analytics/company" element={guard(["company"], <CompanyAnalytics />)} />
          <Route path="/analytics/admin" element={guard(["admin"], <AdminAnalytics />)} />

          <Route path="/dashboard/hacker" element={guard(["hacker"], <HackerDashboard />)} />
          <Route path="/dashboard/company" element={guard(["company"], <CompanyDashboard />)} />
          <Route path="/dashboard/admin" element={guard(["admin"], <AdminDashboard />)} />

          <Route path="/profile" element={guard(undefined, <Profile />)} />
          <Route path="/notifications" element={guard(undefined, <Notifications />)} />
        </Route>

        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Suspense>
  );
}

export default App;
