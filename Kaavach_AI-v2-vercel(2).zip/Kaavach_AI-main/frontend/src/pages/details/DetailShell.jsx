import { useEffect, useState } from "react"
import { Link, useNavigate } from "react-router-dom"
import { useSelector } from "react-redux"
import ReactMarkdown from "react-markdown"
import toast from "react-hot-toast"
import { ArrowLeft, Trash2 } from "lucide-react"
import { errorMessage } from "@/services/api"

// Loads one record and renders a consistent detail page.
export function useRecord(loader, key) {
  const [state, setState] = useState({ loading: true, data: null })
  useEffect(() => {
    let alive = true
    setState({ loading: true, data: null })
    loader()
      .then((res) => alive && setState({ loading: false, data: res.data }))
      .catch(() => alive && setState({ loading: false, data: null }))
    return () => {
      alive = false
    }
  }, [key]) // eslint-disable-line react-hooks/exhaustive-deps
  return state
}

export const Markdown = ({ children }) => (
  <div className="prose prose-invert max-w-none text-sm leading-relaxed prose-a:text-cyan-300 prose-pre:bg-black/40">
    <ReactMarkdown>{children || ""}</ReactMarkdown>
  </div>
)

export default function DetailShell({ backTo, backLabel, loading, notFound, title, meta, ownerId, onDelete, children, aside }) {
  const { user } = useSelector((s) => s.auth)
  const navigate = useNavigate()
  const canDelete = onDelete && user && (user.role === "admin" || (ownerId && String(ownerId) === String(user._id)))

  const remove = async () => {
    if (!window.confirm("Delete this permanently?")) return
    try {
      await onDelete()
      toast.success("Deleted")
      navigate(backTo)
    } catch (err) {
      toast.error(errorMessage(err, "Could not delete"))
    }
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6">
      <Link to={backTo} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-white">
        <ArrowLeft className="h-4 w-4" /> {backLabel}
      </Link>

      {loading ? (
        <div className="flex justify-center py-16">
          <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
        </div>
      ) : notFound ? (
        <div className="card py-16 text-center text-muted-foreground">This item was not found or has been removed.</div>
      ) : (
        <article className="card space-y-5">
          <header className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <h1 className="text-3xl font-semibold text-white">{title}</h1>
              {meta && <div className="mt-2 text-sm text-muted-foreground">{meta}</div>}
            </div>
            <div className="flex items-center gap-2">
              {aside}
              {canDelete && (
                <button onClick={remove} className="btn-danger">
                  <Trash2 className="h-3 w-3" /> Delete
                </button>
              )}
            </div>
          </header>
          {children}
        </article>
      )}
    </div>
  )
}
