import { useParams } from "react-router-dom"
import { ArrowUpRight, Briefcase, MapPin, Wallet } from "lucide-react"
import { extrasService } from "@/services/extrasService"
import DetailShell, { Markdown, useRecord } from "./DetailShell"

export default function JobDetail() {
  const { id } = useParams()
  const { loading, data } = useRecord(() => extrasService.getJob(id), id)
  return (
    <DetailShell
      backTo="/jobs" backLabel="Job board" loading={loading} notFound={!data}
      title={data?.title}
      meta={data && <>{data.companyId?.companyName || data.companyName || "Company"} • Posted {new Date(data.createdAt).toLocaleDateString()}</>}
      ownerId={data?.companyId?._id}
      onDelete={() => extrasService.deleteJob(id)}
      aside={data?.applyUrl && (
        <a href={data.applyUrl} target="_blank" rel="noopener noreferrer" className="btn-primary">Apply <ArrowUpRight className="h-4 w-4" /></a>
      )}
    >
      <div className="flex flex-wrap gap-4 text-sm text-gray-300">
        {data?.location && <span className="flex items-center gap-1"><MapPin className="h-4 w-4 text-cyan-400" />{data.location}</span>}
        {data?.jobType && <span className="flex items-center gap-1"><Briefcase className="h-4 w-4 text-cyan-400" />{data.jobType} • {data.seniority}</span>}
        {data?.salaryRange && <span className="flex items-center gap-1"><Wallet className="h-4 w-4 text-cyan-400" />{data.salaryRange}</span>}
      </div>
      <Markdown>{data?.description}</Markdown>
    </DetailShell>
  )
}
