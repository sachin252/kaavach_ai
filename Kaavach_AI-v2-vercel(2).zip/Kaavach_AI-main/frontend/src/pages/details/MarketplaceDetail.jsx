import { useParams } from "react-router-dom"
import { extrasService } from "@/services/extrasService"
import DetailShell, { Markdown, useRecord } from "./DetailShell"

export default function MarketplaceDetail() {
  const { id } = useParams()
  const { loading, data } = useRecord(() => extrasService.getMarketplaceItem(id), id)
  return (
    <DetailShell
      backTo="/marketplace" backLabel="Marketplace" loading={loading} notFound={!data}
      title={data?.title}
      meta={data && <>Listed by {data.sellerId?.companyName || data.sellerId?.name || "a researcher"} • {new Date(data.createdAt).toLocaleDateString()}</>}
      ownerId={data?.sellerId?._id}
      onDelete={() => extrasService.deleteMarketplaceItem(id)}
      aside={data && <span className="text-2xl font-semibold text-cyan-300">{data.price > 0 ? `₹${data.price}` : "FREE"}</span>}
    >
      <Markdown>{data?.description}</Markdown>
      {data?.tags?.length > 0 && (
        <div className="flex flex-wrap gap-2">{data.tags.map((t) => <span key={t} className="rounded-lg bg-cyan-500/10 px-2 py-1 text-xs text-cyan-300">{t}</span>)}</div>
      )}
      {data?.attachments?.length > 0 && (
        <div>
          <h3 className="mb-2 font-semibold text-white">Resources</h3>
          <ul className="space-y-1 text-sm">
            {data.attachments.map((a) => (
              <li key={a}><a href={a} target="_blank" rel="noopener noreferrer nofollow" className="break-all text-cyan-300 hover:underline">{a}</a></li>
            ))}
          </ul>
          <p className="mt-2 text-xs text-muted-foreground">External links are provided by the seller. Review before downloading.</p>
        </div>
      )}
    </DetailShell>
  )
}
