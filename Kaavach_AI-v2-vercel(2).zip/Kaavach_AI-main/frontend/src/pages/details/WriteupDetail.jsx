import { useParams } from "react-router-dom"
import { extrasService } from "@/services/extrasService"
import DetailShell, { Markdown, useRecord } from "./DetailShell"

export default function WriteupDetail() {
  const { id } = useParams()
  const { loading, data } = useRecord(() => extrasService.getWriteup(id), id)
  return (
    <DetailShell
      backTo="/writeups" backLabel="All writeups" loading={loading} notFound={!data}
      title={data?.title}
      meta={data && <>{data.author?.name || data.authorName || "Researcher"} • {new Date(data.createdAt).toLocaleDateString()} • {data.category}</>}
      ownerId={data?.author?._id}
      onDelete={() => extrasService.deleteWriteup(id)}
    >
      {data?.summary && <p className="text-gray-300">{data.summary}</p>}
      <Markdown>{data?.content}</Markdown>
      {data?.tags?.length > 0 && (
        <div className="flex flex-wrap gap-2">{data.tags.map((t) => <span key={t} className="rounded-lg bg-cyan-500/10 px-2 py-1 text-xs text-cyan-300">{t}</span>)}</div>
      )}
    </DetailShell>
  )
}
