import { useParams } from "react-router-dom"
import { extrasService } from "@/services/extrasService"
import DetailShell, { Markdown, useRecord } from "./DetailShell"

export default function KBArticleDetail() {
  const { slug } = useParams()
  const { loading, data } = useRecord(() => extrasService.getKBArticle(slug), slug)
  return (
    <DetailShell
      backTo="/kb" backLabel="Knowledge base" loading={loading} notFound={!data}
      title={data?.title}
      meta={data && <span className="capitalize">{data.category} • {data.readTime} min read • Updated {new Date(data.updatedAt).toLocaleDateString()}</span>}
      ownerId={null}
      onDelete={() => extrasService.deleteKBArticle(data._id)}
    >
      <p className="text-gray-300">{data?.summary}</p>
      <Markdown>{data?.content}</Markdown>
    </DetailShell>
  )
}
