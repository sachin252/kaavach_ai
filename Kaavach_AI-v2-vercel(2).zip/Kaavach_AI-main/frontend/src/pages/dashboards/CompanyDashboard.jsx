import { useCallback, useEffect, useMemo, useState } from "react"
import { useSelector } from "react-redux"
import { Link } from "react-router-dom"
import toast from "react-hot-toast"
import { AlertCircle, Building2, DollarSign, Download, FileText, Plus, X } from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts"

import { programService } from "@/services/programService"
import { reportService, downloadReportFile } from "@/services/reportService"
import { analyticsService } from "@/services/analyticsService"
import { errorMessage } from "@/services/api"
import { money } from "@/lib/format"
import { statusClass } from "./HackerDashboard"

const SEVERITIES = ["low", "medium", "high", "critical"]
const STATUSES = ["pending", "triaged", "accepted", "rejected", "duplicate"]
const emptyProgram = { title: "", description: "", rules: "", severityLevels: [], rewardRange: { min: 0, max: 0 }, inScope: "", outOfScope: "" }

const Stat = ({ label, value, icon: Icon, color }) => (
  <div className="card">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="text-2xl font-bold">{value}</p>
      </div>
      <Icon className={`h-8 w-8 ${color}`} />
    </div>
  </div>
)

const CompanyDashboard = () => {
  const { user } = useSelector((s) => s.auth)
  const [programs, setPrograms] = useState([])
  const [reports, setReports] = useState([])
  const [analytics, setAnalytics] = useState({ funnel: [], rewards: {}, ttr: {} })
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState("all")

  const [showProgramModal, setShowProgramModal] = useState(false)
  const [programData, setProgramData] = useState(emptyProgram)
  const [savingProgram, setSavingProgram] = useState(false)

  const [selected, setSelected] = useState(null)
  const [reviewData, setReviewData] = useState({ status: "pending", reward: 0, reviewNotes: "" })
  const [savingReview, setSavingReview] = useState(false)

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      const [programsData, reportsData, funnel, rewards, ttr] = await Promise.all([
        programService.getPrograms({ mine: true, limit: 50 }),
        reportService.getCompanyReports(),
        analyticsService.getCompanyReportFunnel(),
        analyticsService.getCompanyRewardSummary(),
        analyticsService.getCompanyTTR(),
      ])
      setPrograms(programsData.programs || [])
      setReports(reportsData || [])
      setAnalytics({ funnel: funnel.data || [], rewards: rewards.data || {}, ttr: ttr.data || {} })
    } catch {
      toast.error("Failed to load dashboard data")
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const pending = reports.filter((r) => r.status === "pending").length
  const visibleReports = useMemo(() => (filter === "all" ? reports : reports.filter((r) => r.status === filter)), [reports, filter])

  const handleCreateProgram = async (e) => {
    e.preventDefault()
    if (programData.severityLevels.length === 0) return toast.error("Select at least one severity level")
    if (Number(programData.rewardRange.max) < Number(programData.rewardRange.min)) return toast.error("Max reward must be ≥ min reward")
    try {
      setSavingProgram(true)
      await programService.createProgram(programData)
      toast.success("Program launched")
      setShowProgramModal(false)
      setProgramData(emptyProgram)
      fetchData()
    } catch (err) {
      toast.error(errorMessage(err, "Failed to create program"))
    } finally {
      setSavingProgram(false)
    }
  }

  const toggleProgramStatus = async (p) => {
    const next = p.status === "active" ? "inactive" : "active"
    try {
      await programService.updateProgram(p._id, { status: next })
      toast.success(next === "active" ? "Program reopened" : "Program paused")
      fetchData()
    } catch (err) {
      toast.error(errorMessage(err, "Could not update program"))
    }
  }

  const toggleSeverity = (sev) =>
    setProgramData((d) => ({
      ...d,
      severityLevels: d.severityLevels.includes(sev) ? d.severityLevels.filter((s) => s !== sev) : [...d.severityLevels, sev],
    }))

  const openReview = (r) => {
    setSelected(r)
    setReviewData({ status: r.status, reward: r.reward || 0, reviewNotes: r.reviewNotes || "" })
  }

  const handleReview = async (e) => {
    e.preventDefault()
    try {
      setSavingReview(true)
      const res = await reportService.updateReportStatus(selected._id, reviewData)
      toast.success(res.xpAwarded ? `Report accepted. Researcher earned ${res.xpAwarded} XP.` : "Report updated")
      setSelected(null)
      fetchData()
    } catch (err) {
      toast.error(errorMessage(err, "Failed to update report"))
    } finally {
      setSavingReview(false)
    }
  }

  const download = async (r) => {
    try {
      await downloadReportFile(r)
    } catch {
      toast.error("Could not download the attachment")
    }
  }

  if (loading && programs.length === 0 && reports.length === 0) {
    return (
      <div className="flex justify-center py-16">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Company Ops</h1>
          <p className="text-sm text-muted-foreground">{user?.companyName || user?.name}</p>
        </div>
        <button onClick={() => setShowProgramModal(true)} className="btn-primary" disabled={!user?.isApproved}>
          <Plus className="h-4 w-4" /> Create program
        </button>
      </div>

      {user && !user.isApproved && (
        <div className="rounded-2xl border border-yellow-400/30 bg-yellow-500/10 p-4 text-sm text-yellow-200">
          Your company account is awaiting admin approval. You can create programs once it is approved.
        </div>
      )}

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Stat label="Programs" value={programs.length} icon={Building2} color="text-cyan-400" />
        <Stat label="Reports" value={reports.length} icon={FileText} color="text-blue-400" />
        <Stat label="Pending review" value={pending} icon={AlertCircle} color="text-yellow-400" />
        <Stat label="Rewards paid" value={money(analytics.rewards.totalRewards)} icon={DollarSign} color="text-green-400" />
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <div className="card">
          <h2 className="mb-3 font-semibold">Report funnel</h2>
          {analytics.funnel.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={analytics.funnel}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                <XAxis dataKey="_id" stroke="#94a3b8" fontSize={12} />
                <YAxis allowDecimals={false} stroke="#94a3b8" fontSize={12} />
                <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #1e293b" }} />
                <Bar dataKey="count" fill="#22d3ee" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="py-12 text-center text-sm text-muted-foreground">No reports yet</p>
          )}
        </div>
        <div className="card space-y-2">
          <h2 className="font-semibold">Reward summary</h2>
          <p className="text-sm text-muted-foreground">Total paid</p>
          <p className="text-2xl font-bold text-emerald-400">{money(analytics.rewards.totalRewards)}</p>
          <p className="text-sm text-muted-foreground">Average bounty</p>
          <p className="text-xl font-semibold text-cyan-400">{money(analytics.rewards.avgReward)}</p>
        </div>
        <div className="card space-y-2">
          <h2 className="font-semibold">Avg time to resolve</h2>
          <p className="text-3xl font-bold text-cyan-300">{(analytics.ttr.avgTTR || 0).toFixed(1)} days</p>
          <p className="text-xs text-muted-foreground">From submission to first decision. Researchers see this on your program page.</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
        <div className="card">
          <h2 className="mb-3 font-semibold">My programs</h2>
          {programs.length === 0 ? (
            <p className="text-sm text-muted-foreground">No programs yet. Launch your first one to start receiving reports.</p>
          ) : (
            <div className="space-y-2">
              {programs.map((p) => (
                <div key={p._id} className="rounded-xl border border-white/10 p-3">
                  <div className="flex items-start justify-between gap-2">
                    <Link to={`/programs/${p._id}`} className="font-semibold hover:text-cyan-300">{p.title}</Link>
                    <span className={`rounded px-2 py-1 text-xs ${p.status === "active" ? "bg-green-500/15 text-green-300" : "bg-gray-500/20 text-gray-300"}`}>
                      {p.status}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {p.reportCount || 0} reports • {money(p.rewardRange?.min)} – {money(p.rewardRange?.max)}
                  </p>
                  <button onClick={() => toggleProgramStatus(p)} className="mt-2 text-xs text-cyan-300 hover:underline">
                    {p.status === "active" ? "Pause program" : "Reopen program"}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="card">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <h2 className="font-semibold">Incoming reports</h2>
            <div className="flex flex-wrap gap-1 text-xs">
              {["all", ...STATUSES].map((s) => (
                <button key={s} onClick={() => setFilter(s)}
                  className={`rounded-full border px-3 py-1 capitalize ${filter === s ? "border-cyan-400 bg-cyan-500/20 text-cyan-100" : "border-white/10 text-gray-300"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          {visibleReports.length === 0 ? (
            <p className="text-sm text-muted-foreground">No reports in this view.</p>
          ) : (
            <div className="max-h-[560px] space-y-2 overflow-y-auto pr-1">
              {visibleReports.map((r) => (
                <button key={r._id} onClick={() => openReview(r)} className="block w-full rounded-xl border border-white/10 p-3 text-left transition hover:bg-white/5">
                  <div className="flex justify-between gap-2">
                    <h3 className="font-semibold">{r.title}</h3>
                    <span className={`h-fit rounded px-2 py-1 text-xs capitalize ${statusClass(r.status)}`}>{r.status}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {r.program?.title} • <span className="capitalize">{r.severity}</span> • by {r.submittedBy?.name || "deleted user"} • {new Date(r.createdAt).toLocaleDateString()}
                  </p>
                  {r.reward > 0 && <p className="text-sm text-green-400">Reward: {money(r.reward)}</p>}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {showProgramModal && (
        <div className="modal-backdrop">
          <div className="modal-panel">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-cyan-300">Launch a program</h2>
              <button onClick={() => setShowProgramModal(false)} className="rounded-xl p-2 hover:bg-white/10"><X className="h-5 w-5" /></button>
            </div>
            <form onSubmit={handleCreateProgram} className="space-y-4">
              <label className="block text-sm">Title
                <input required maxLength={140} className="input-field" value={programData.title} onChange={(e) => setProgramData({ ...programData, title: e.target.value })} />
              </label>
              <label className="block text-sm">Description (Markdown supported)
                <textarea required rows={3} className="input-field" value={programData.description} onChange={(e) => setProgramData({ ...programData, description: e.target.value })} />
              </label>
              <label className="block text-sm">Rules of engagement
                <textarea required rows={3} className="input-field" placeholder="No DoS, use test accounts only, report within 24h…" value={programData.rules} onChange={(e) => setProgramData({ ...programData, rules: e.target.value })} />
              </label>
              <div className="grid gap-4 md:grid-cols-2">
                <label className="block text-sm">In scope (comma separated)
                  <input className="input-field" placeholder="*.example.com, api.example.com" value={programData.inScope} onChange={(e) => setProgramData({ ...programData, inScope: e.target.value })} />
                </label>
                <label className="block text-sm">Out of scope (comma separated)
                  <input className="input-field" placeholder="blog.example.com" value={programData.outOfScope} onChange={(e) => setProgramData({ ...programData, outOfScope: e.target.value })} />
                </label>
              </div>
              <div>
                <p className="text-sm">Accepted severities</p>
                <div className="mt-2 flex flex-wrap gap-2">
                  {SEVERITIES.map((sev) => (
                    <button type="button" key={sev} onClick={() => toggleSeverity(sev)}
                      className={`rounded-full border px-3 py-1 text-sm capitalize ${programData.severityLevels.includes(sev) ? "border-cyan-400 bg-cyan-500/20 text-cyan-100" : "border-white/15 text-gray-300"}`}>
                      {sev}
                    </button>
                  ))}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <label className="block text-sm">Min reward ($)
                  <input type="number" min={0} required className="input-field" value={programData.rewardRange.min}
                    onChange={(e) => setProgramData({ ...programData, rewardRange: { ...programData.rewardRange, min: e.target.value } })} />
                </label>
                <label className="block text-sm">Max reward ($)
                  <input type="number" min={1} required className="input-field" value={programData.rewardRange.max}
                    onChange={(e) => setProgramData({ ...programData, rewardRange: { ...programData.rewardRange, max: e.target.value } })} />
                </label>
              </div>
              <div className="flex justify-end gap-3">
                <button type="button" className="btn-secondary" onClick={() => setShowProgramModal(false)}>Cancel</button>
                <button type="submit" className="btn-primary" disabled={savingProgram}>{savingProgram ? "Launching…" : "Launch program"}</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {selected && (
        <div className="modal-backdrop">
          <div className="modal-panel">
            <div className="mb-4 flex items-start justify-between gap-4">
              <div>
                <p className="text-xs uppercase text-muted-foreground">{selected.program?.title}</p>
                <h2 className="text-2xl font-bold text-white">{selected.title}</h2>
                <p className="text-sm text-muted-foreground">
                  <span className="capitalize">{selected.severity}</span> • submitted by {selected.submittedBy?.name || "deleted user"}
                  {selected.submittedBy?.tier ? ` (${selected.submittedBy.tier}, L${selected.submittedBy.level})` : ""} • {new Date(selected.createdAt).toLocaleString()}
                </p>
              </div>
              <button onClick={() => setSelected(null)} className="rounded-xl p-2 hover:bg-white/10"><X className="h-5 w-5" /></button>
            </div>

            <div className="mb-4 max-h-64 overflow-y-auto whitespace-pre-wrap rounded-xl border border-white/10 bg-black/30 p-4 text-sm text-gray-200">
              {selected.description}
            </div>
            <button onClick={() => download(selected)} className="btn-secondary mb-5">
              <Download className="h-4 w-4" /> Download attachment ({selected.fileName})
            </button>

            <form onSubmit={handleReview} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <label className="block text-sm">Status
                  <select className="input-field capitalize" value={reviewData.status} onChange={(e) => setReviewData({ ...reviewData, status: e.target.value })}>
                    {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </label>
                <label className="block text-sm">Reward ($)
                  <input type="number" min={0} max={selected.program?.rewardRange?.max || undefined} className="input-field"
                    disabled={reviewData.status !== "accepted"} value={reviewData.reward}
                    onChange={(e) => setReviewData({ ...reviewData, reward: e.target.value === "" ? "" : Number(e.target.value) })} />
                </label>
              </div>
              {selected.program?.rewardRange && (
                <p className="text-xs text-muted-foreground">Program range: {money(selected.program.rewardRange.min)} – {money(selected.program.rewardRange.max)}</p>
              )}
              <label className="block text-sm">Notes to researcher
                <textarea rows={3} className="input-field" value={reviewData.reviewNotes} onChange={(e) => setReviewData({ ...reviewData, reviewNotes: e.target.value })} />
              </label>
              <div className="flex justify-end gap-3">
                <button type="button" className="btn-secondary" onClick={() => setSelected(null)}>Cancel</button>
                <button type="submit" className="btn-primary" disabled={savingReview}>{savingReview ? "Saving…" : "Save decision"}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}

export default CompanyDashboard
