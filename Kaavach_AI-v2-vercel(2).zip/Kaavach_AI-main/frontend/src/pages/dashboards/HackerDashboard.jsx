import { useCallback, useEffect, useState } from "react"
import { Link, useSearchParams } from "react-router-dom"
import { useDispatch, useSelector } from "react-redux"
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from "recharts"
import { Download, Plus } from "lucide-react"
import toast from "react-hot-toast"

import { programService } from "@/services/programService"
import { reportService, downloadReportFile } from "@/services/reportService"
import { leaderboardService } from "@/services/leaderboardService"
import { analyticsService } from "@/services/analyticsService"
import { authService } from "@/services/authService"
import { setUser } from "@/store/slices/authSlice"
import StatsCard from "@/components/ui/StatsCard"
import BadgeList from "@/components/ui/BadgeList"
import LevelProgress from "@/components/ui/LevelProgress"
import SubmitReportModal from "@/components/SubmitReportModal"
import { money } from "@/lib/format"

const SEV_COLORS = { Critical: "#EF4444", High: "#F59E0B", Medium: "#10B981", Low: "#3B82F6" }
export const statusClass = (status) =>
  ({
    pending: "bg-yellow-500/15 text-yellow-300",
    accepted: "bg-green-500/15 text-green-300",
    rejected: "bg-red-500/15 text-red-300",
    triaged: "bg-blue-500/15 text-blue-300",
    duplicate: "bg-gray-500/20 text-gray-300",
  }[status] || "bg-gray-500/20 text-gray-300")

const HackerDashboard = () => {
  const { user } = useSelector((s) => s.auth)
  const dispatch = useDispatch()
  const [params, setParams] = useSearchParams()

  const [stats, setStats] = useState(null)
  const [programs, setPrograms] = useState([])
  const [reports, setReports] = useState([])
  const [severityData, setSeverityData] = useState([])
  const [monthlyData, setMonthlyData] = useState([])
  const [loading, setLoading] = useState(true)
  const [showSubmit, setShowSubmit] = useState(false)
  const [showAll, setShowAll] = useState(false)

  const fetchAll = useCallback(async () => {
    try {
      setLoading(true)
      const [statsData, programsData, reportsData, sev, mon, me] = await Promise.all([
        leaderboardService.getMyStats(),
        programService.getPrograms({ status: "active", limit: 50 }),
        reportService.getMyReports(),
        analyticsService.getSeverityStats(),
        analyticsService.getMonthlyActivity(),
        authService.getMe(),
      ])
      setStats(statsData)
      setPrograms(programsData.programs || [])
      setReports(reportsData || [])
      dispatch(setUser(me))

      const map = { critical: 0, high: 0, medium: 0, low: 0 }
      sev.data?.forEach((s) => (map[s._id] = s.count))
      setSeverityData(
        [["Critical", map.critical], ["High", map.high], ["Medium", map.medium], ["Low", map.low]]
          .filter(([, v]) => v > 0)
          .map(([name, value]) => ({ name, value }))
      )
      setMonthlyData((mon.data || []).map((m) => ({ month: m.month, count: m.count })))
    } catch (error) {
      toast.error("Failed to load dashboard data")
    } finally {
      setLoading(false)
    }
  }, [dispatch])

  useEffect(() => {
    fetchAll()
  }, [fetchAll])

  // /dashboard/hacker?program=<id> opens the submit form for that program
  useEffect(() => {
    if (params.get("program")) setShowSubmit(true)
  }, [params])

  const closeSubmit = () => {
    setShowSubmit(false)
    if (params.get("program")) setParams({}, { replace: true })
  }

  const download = async (r) => {
    try {
      await downloadReportFile(r)
    } catch {
      toast.error("Could not download the attachment")
    }
  }

  if (loading && !stats) {
    return (
      <div className="flex justify-center py-16">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" />
      </div>
    )
  }

  const visibleReports = showAll ? reports : reports.slice(0, 6)

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white">Hacker HQ</h1>
          <p className="text-sm text-muted-foreground">Welcome back, {user?.name}.</p>
        </div>
        <button onClick={() => setShowSubmit(true)} className="btn-primary">
          <Plus className="h-4 w-4" /> Submit report
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <StatsCard title="Total reports" value={stats?.totalReports ?? 0} subtitle={`${stats?.pendingReports ?? 0} pending`} />
        <StatsCard title="Accepted" value={stats?.acceptedReports ?? 0} />
        <StatsCard title="Bounties earned" value={money(stats?.totalRewards)} />
        <StatsCard title="Points" value={stats?.points ?? 0} />
        <StatsCard title="Rank" value={`#${stats?.rank ?? "—"}`} />
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="card lg:col-span-2">
          <h3 className="mb-3 font-semibold">Monthly activity</h3>
          <div style={{ height: 220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={12} />
                <YAxis allowDecimals={false} stroke="#94a3b8" fontSize={12} />
                <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #1e293b" }} />
                <Line type="monotone" dataKey="count" name="Reports" stroke="#22d3ee" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <h3 className="mb-3 font-semibold">Severity distribution</h3>
          {severityData.length === 0 ? (
            <p className="py-16 text-center text-sm text-muted-foreground">No reports yet</p>
          ) : (
            <div style={{ height: 220 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={severityData} dataKey="value" nameKey="name" innerRadius={50} outerRadius={90} label>
                    {severityData.map((d) => (
                      <Cell key={d.name} fill={SEV_COLORS[d.name]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #1e293b" }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <LevelProgress xp={user?.xp || 0} level={user?.level || 1} tier={user?.tier || "Bronze"} />
        <div className="card">
          <h3 className="mb-3 font-semibold">Your badges</h3>
          <BadgeList badges={user?.badges || []} />
          <p className="mt-3 text-xs text-muted-foreground">Streak: {user?.streak || 0} days • Impact score: {user?.impactScore || 0}</p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-xl font-semibold">Active programs</h3>
            <Link to="/programs" className="text-xs text-cyan-300 hover:underline">View all →</Link>
          </div>
          {programs.length === 0 ? (
            <p className="text-sm text-muted-foreground">No active programs right now.</p>
          ) : (
            <div className="space-y-3">
              {programs.slice(0, 6).map((p) => (
                <Link key={p._id} to={`/programs/${p._id}`} className="block rounded-xl border border-white/10 p-3 transition hover:bg-white/5">
                  <div className="flex justify-between gap-2">
                    <h4 className="font-semibold">{p.title}</h4>
                    <span className="text-xs text-emerald-300">{money(p.rewardRange?.min)} – {money(p.rewardRange?.max)}</span>
                  </div>
                  <p className="line-clamp-1 text-sm text-muted-foreground">{p.createdBy?.companyName || p.createdBy?.name} • {p.description}</p>
                </Link>
              ))}
            </div>
          )}
        </div>

        <div className="card">
          <h3 className="mb-3 text-xl font-semibold">My reports</h3>
          {reports.length === 0 ? (
            <p className="text-sm text-muted-foreground">No reports submitted yet.</p>
          ) : (
            <div className="space-y-3">
              {visibleReports.map((r) => (
                <div key={r._id} className="rounded-xl border border-white/10 p-3">
                  <div className="flex justify-between gap-2">
                    <h4 className="font-semibold">{r.title}</h4>
                    <span className={`h-fit rounded px-2 py-1 text-xs capitalize ${statusClass(r.status)}`}>{r.status}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {r.program?.title} • <span className="capitalize">{r.severity}</span> • {new Date(r.createdAt).toLocaleDateString()}
                  </p>
                  {r.reward > 0 && <p className="text-sm font-medium text-green-400">Reward: {money(r.reward)}</p>}
                  {r.reviewNotes && <p className="mt-1 text-xs text-gray-400">Company notes: {r.reviewNotes}</p>}
                  <button onClick={() => download(r)} className="mt-2 inline-flex items-center gap-1 text-xs text-cyan-300 hover:underline">
                    <Download className="h-3 w-3" /> {r.fileName}
                  </button>
                </div>
              ))}
              {reports.length > 6 && (
                <button className="btn-secondary w-full" onClick={() => setShowAll((v) => !v)}>
                  {showAll ? "Show less" : `Show all ${reports.length} reports`}
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {showSubmit && (
        <SubmitReportModal programs={programs} defaultProgram={params.get("program") || ""} onClose={closeSubmit} onSubmitted={fetchAll} />
      )}
    </div>
  )
}

export default HackerDashboard
