import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import toast from "react-hot-toast"
import { Bell } from "lucide-react"
import { notificationService } from "@/services/notificationService"

export default function Notifications() {
  const [items, setItems] = useState(null)

  const load = () =>
    notificationService
      .getMyNotifications()
      .then((r) => setItems(r.data))
      .catch(() => {
        toast.error("Failed to load notifications")
        setItems([])
      })

  useEffect(() => {
    load()
  }, [])

  const markAll = async () => {
    await notificationService.markAllRead()
    setItems((prev) => prev.map((n) => ({ ...n, read: true })))
  }
  const markOne = async (id) => {
    await notificationService.markRead(id)
    setItems((prev) => prev.map((n) => (n._id === id ? { ...n, read: true } : n)))
  }

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="flex items-center gap-3 text-3xl font-bold text-white"><Bell className="h-7 w-7 text-cyan-300" /> Notifications</h1>
        {items?.some((n) => !n.read) && <button className="btn-secondary" onClick={markAll}>Mark all read</button>}
      </div>
      {items === null ? (
        <div className="flex justify-center py-16"><div className="h-8 w-8 animate-spin rounded-full border-2 border-cyan-400 border-t-transparent" /></div>
      ) : items.length === 0 ? (
        <div className="card py-12 text-center text-muted-foreground">You’re all caught up.</div>
      ) : (
        <div className="space-y-3">
          {items.map((n) => (
            <div key={n._id} className={`card flex items-start justify-between gap-4 ${n.read ? "opacity-70" : "border-cyan-400/40"}`}>
              <div>
                <p className="font-semibold text-white">{n.title}</p>
                <p className="text-sm text-gray-300">{n.body}</p>
                <p className="mt-1 text-xs text-muted-foreground">{new Date(n.createdAt).toLocaleString()}</p>
                {n.link && <Link to={n.link} onClick={() => !n.read && markOne(n._id)} className="mt-1 inline-block text-xs text-cyan-300 hover:underline">Open →</Link>}
              </div>
              {!n.read && <button className="text-xs text-cyan-300 hover:underline" onClick={() => markOne(n._id)}>Mark read</button>}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
