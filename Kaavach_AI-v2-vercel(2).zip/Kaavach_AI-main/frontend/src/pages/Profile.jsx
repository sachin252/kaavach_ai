import { useState, useEffect } from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { authService } from '../services/authService'
import { setUser } from '../store/slices/authSlice'
import toast from 'react-hot-toast'
import { User, Mail, Shield, Building2, Bug, Save, Globe, KeyRound } from 'lucide-react'
import { COUNTRIES } from '@/lib/format'

const Profile = () => {
  const { user } = useSelector((state) => state.auth)
  const dispatch = useDispatch()
  const [formData, setFormData] = useState({
    name: '',
    bio: '',
    companyName: '',
    companyWebsite: '',
    country: '',
  })
  const [loading, setLoading] = useState(false)
  const [pw, setPw] = useState({ currentPassword: '', newPassword: '', confirm: '' })
  const [pwSaving, setPwSaving] = useState(false)

  const changePassword = async (e) => {
    e.preventDefault()
    if (pw.newPassword.length < 8) return toast.error('New password must be at least 8 characters')
    if (pw.newPassword !== pw.confirm) return toast.error('Passwords do not match')
    try {
      setPwSaving(true)
      await authService.changePassword(pw.currentPassword, pw.newPassword)
      toast.success('Password updated')
      setPw({ currentPassword: '', newPassword: '', confirm: '' })
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to update password')
    } finally {
      setPwSaving(false)
    }
  }

  useEffect(() => {
    if (user) {
      setFormData({
        name: user.name || '',
        bio: user.bio || '',
        companyName: user.companyName || '',
        companyWebsite: user.companyWebsite || '',
        country: user.country || '',
      })
    }
  }, [user])

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      const updatedUser = await authService.updateProfile(formData)
      dispatch(setUser(updatedUser))
      toast.success('Profile updated successfully')
    } catch (error) {
      toast.error(error.response?.data?.message || 'Failed to update profile')
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Profile Settings</h1>

      <div className="card">
        <div className="flex items-center space-x-4 mb-6">
          <div className="h-20 w-20 rounded-full bg-primary-100 dark:bg-primary-900 flex items-center justify-center">
            {user.role === 'hacker' && <Bug className="h-10 w-10 text-primary-600 dark:text-primary-400" />}
            {user.role === 'company' && (
              <Building2 className="h-10 w-10 text-primary-600 dark:text-primary-400" />
            )}
            {user.role === 'admin' && (
              <Shield className="h-10 w-10 text-primary-600 dark:text-primary-400" />
            )}
          </div>
          <div>
            <h2 className="text-2xl font-semibold text-gray-900 dark:text-white">{user.name}</h2>
            <p className="text-gray-600 dark:text-gray-400 capitalize">{user.role}</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              <User className="inline h-4 w-4 mr-2" />
              Full Name
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className="input-field"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              <Mail className="inline h-4 w-4 mr-2" />
              Email
            </label>
            <input
              type="email"
              value={user.email}
              className="input-field bg-gray-100 dark:bg-gray-700 cursor-not-allowed"
              disabled
            />
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Email cannot be changed</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Bio
            </label>
            <textarea
              name="bio"
              value={formData.bio}
              onChange={handleChange}
              className="input-field"
              rows={4}
              placeholder="Tell us about yourself..."
            />
          </div>

          {user.role === 'company' && (
            <>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  <Building2 className="inline h-4 w-4 mr-2" />
                  Company Name
                </label>
                <input
                  type="text"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleChange}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Company Website
                </label>
                <input
                  type="url"
                  name="companyWebsite"
                  value={formData.companyWebsite}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="https://example.com"
                />
              </div>
            </>
          )}

          {user.role === 'hacker' && (
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="text-sm text-gray-600 dark:text-gray-400">Points</div>
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  {user.points || 0}
                </div>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="text-sm text-gray-600 dark:text-gray-400">Level</div>
                <div className="text-2xl font-bold text-gray-900 dark:text-white">
                  L{user.level || 1} · {user.tier || 'Bronze'}
                </div>
              </div>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              <Globe className="inline h-4 w-4 mr-2" />
              Country
            </label>
            <select name="country" value={formData.country} onChange={handleChange} className="input-field">
              <option value="">Prefer not to say</option>
              {COUNTRIES.map(([v, l]) => (
                <option key={v} value={v}>{l}</option>
              ))}
            </select>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={loading}
              className="btn-primary flex items-center space-x-2 disabled:opacity-50"
            >
              <Save className="h-5 w-5" />
              <span>{loading ? 'Saving...' : 'Save Changes'}</span>
            </button>
          </div>
        </form>
      </div>

      <div className="card">
        <h2 className="mb-4 flex items-center gap-2 text-xl font-semibold text-white">
          <KeyRound className="h-5 w-5 text-cyan-300" /> Change password
        </h2>
        <form onSubmit={changePassword} className="grid gap-4 md:grid-cols-3">
          <input type="password" required autoComplete="current-password" placeholder="Current password" className="input-field"
            value={pw.currentPassword} onChange={(e) => setPw({ ...pw, currentPassword: e.target.value })} />
          <input type="password" required minLength={8} autoComplete="new-password" placeholder="New password (8+ chars)" className="input-field"
            value={pw.newPassword} onChange={(e) => setPw({ ...pw, newPassword: e.target.value })} />
          <input type="password" required autoComplete="new-password" placeholder="Confirm new password" className="input-field"
            value={pw.confirm} onChange={(e) => setPw({ ...pw, confirm: e.target.value })} />
          <div className="md:col-span-3 flex justify-end">
            <button type="submit" className="btn-primary" disabled={pwSaving}>{pwSaving ? 'Updating…' : 'Update password'}</button>
          </div>
        </form>
      </div>
    </div>
  )
}

export default Profile

