import { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { useNavigate } from "react-router-dom"
import { ArrowUpRight, Building2, Bug, CheckCircle2, Shield, Trophy, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { statsService } from "@/services/statsService"
import { compact, money } from "@/lib/format"

const Home = () => {
  const { user } = useSelector((state) => state.auth)
  const navigate = useNavigate()
  const [stats, setStats] = useState(null)

  useEffect(() => {
    statsService.getPublicStats().then(setStats).catch(() => setStats({}))
  }, [])

  const s = stats || {}
  const tiles = [
    { label: "Active programs", value: compact(s.activePrograms), detail: s.newProgramsLast30Days ? `+${s.newProgramsLast30Days} in last 30 days` : "Open for submissions", icon: Shield },
    { label: "Rewards paid", value: money(s.totalRewards), detail: s.avgBounty ? `Avg bounty ${money(s.avgBounty)}` : "Paid to researchers", icon: Trophy },
    { label: "Researchers", value: compact(s.researchers), detail: `${compact(s.totalReports)} reports submitted`, icon: Users },
    { label: "Avg first response", value: s.avgResponseHours != null ? `${s.avgResponseHours}h` : "—", detail: `${compact(s.reportsToday)} reports in last 24h`, icon: CheckCircle2 },
  ]

  const showcase = [
    { title: "Writeups Hub", path: "/writeups", desc: "Research breakdowns published by the community." },
    { title: "Marketplace", path: "/marketplace", desc: "Tools, templates and playbooks from researchers." },
    { title: "Job Board", path: "/jobs", desc: "Security roles and freelance engagements." },
    { title: "Breach Alerts", path: "/breach-alerts", desc: "Curated breach and exposure advisories." },
  ]

  const steps = {
    hackers: [
      "Create a free researcher account",
      "Pick an active program and read its scope",
      "Submit a report with proof (PDF/DOCX)",
      "Earn bounties, XP, badges and leaderboard rank",
    ],
    companies: [
      "Register your company",
      "Launch a program with scope and reward ranges",
      "Triage reports in one dashboard",
      "Reward valid findings and track time-to-resolve",
    ],
  }

  return (
    <div className="space-y-10">
      <section className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-r from-slate-900 via-slate-900/80 to-black px-6 py-10 md:px-12 md:py-14">
        <div className="relative grid gap-10 lg:grid-cols-[1.1fr_0.9fr]">
          <div className="space-y-6">
            <Badge variant="outline" className="text-xs uppercase tracking-wide text-cyan-200">
              Bug bounty & vulnerability disclosure platform
            </Badge>
            <h1 className="text-4xl font-semibold leading-tight text-white md:text-5xl">
              Find vulnerabilities before attackers do.
            </h1>
            <p className="max-w-2xl text-lg text-muted-foreground">
              Kaavach AI connects companies with independent security researchers. Launch a bounty program,
              receive verified reports, and pay only for valid findings.
            </p>

            <div className="mt-4 flex flex-wrap gap-4">
              {!user ? (
                <>
                  <Button size="lg" onClick={() => navigate("/register")}>Create free account</Button>
                  <Button variant="outline" size="lg" onClick={() => navigate("/programs")} className="border-cyan-400/40 text-cyan-200 hover:bg-cyan-400/10">
                    Browse programs <ArrowUpRight className="ml-2 h-4 w-4" />
                  </Button>
                </>
              ) : (
                <>
                  <Button size="lg" onClick={() => navigate(`/dashboard/${user.role}`)}>Go to dashboard</Button>
                  <Button variant="outline" size="lg" onClick={() => navigate("/programs")} className="border-cyan-400/40 text-cyan-200 hover:bg-cyan-400/10">
                    Explore programs <ArrowUpRight className="ml-2 h-4 w-4" />
                  </Button>
                </>
              )}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {tiles.map(({ label, value, detail, icon: Icon }) => (
              <div key={label} className="rounded-2xl border border-white/10 bg-white/5 p-4">
                <Icon className="h-5 w-5 text-cyan-300" />
                <p className="mt-3 text-xs uppercase text-muted-foreground">{label}</p>
                <p className="mt-1 text-3xl font-semibold text-white">{stats ? value : "…"}</p>
                <p className="mt-1 text-xs text-emerald-300">{stats ? detail : ""}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="grid gap-6 md:grid-cols-2">
        {[
          { key: "hackers", title: "For security researchers", icon: Bug, cta: "Join as researcher" },
          { key: "companies", title: "For companies", icon: Building2, cta: "Launch a program" },
        ].map(({ key, title, icon: Icon, cta }) => (
          <Card key={key} className="rounded-3xl border-white/10 bg-white/5 p-6">
            <CardContent className="space-y-4 p-0">
              <div className="flex items-center gap-3">
                <Icon className="h-6 w-6 text-cyan-300" />
                <h3 className="text-2xl font-semibold text-white">{title}</h3>
              </div>
              <ol className="space-y-2 text-sm text-muted-foreground">
                {steps[key].map((step, i) => (
                  <li key={step} className="flex gap-3">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-cyan-500/15 text-xs font-semibold text-cyan-200">{i + 1}</span>
                    {step}
                  </li>
                ))}
              </ol>
              {!user && (
                <Button variant="outline" onClick={() => navigate("/register")} className="border-cyan-400/40 text-cyan-200">
                  {cta}
                </Button>
              )}
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="rounded-3xl border border-white/10 bg-gradient-to-br from-cyan-500/10 to-blue-600/10 p-6">
        <h3 className="text-2xl font-semibold text-white">Community & intelligence</h3>
        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {showcase.map((card) => (
            <button
              key={card.title}
              onClick={() => navigate(card.path)}
              className="rounded-2xl border border-white/10 p-4 text-left transition hover:bg-white/10"
            >
              <p className="text-lg font-semibold text-white">{card.title}</p>
              <p className="text-xs text-muted-foreground">{card.desc}</p>
            </button>
          ))}
        </div>
      </section>
    </div>
  )
}

export default Home
