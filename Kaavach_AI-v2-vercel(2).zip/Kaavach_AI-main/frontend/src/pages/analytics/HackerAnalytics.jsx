import { useEffect, useState } from "react"
import toast from "react-hot-toast"
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts"
import { analyticsService } from "@/services/analyticsService"
import StatsCard from "@/components/ui/StatsCard"
import { Skeleton } from "@/components/ui/skeleton"
import { money } from "@/lib/format"

const SEV = { critical: "#ef4444", high: "#f97316", medium: "#eab308", low: "#22c55e" }
const tip = { background: "#0f172a", border: "1px solid #1e293b" }

export default function HackerAnalytics() {
  const [data, setData] = useState(null)

  useEffect(() => {
    Promise.all([
      analyticsService.getSeverityStats(),
      analyticsService.getMonthlyActivity(),
      analyticsService.getAcceptanceStats(),
      analyticsService.getImpactScore(),
      analyticsService.getHackerSummary(),
    ])
      .then(([sev, mon, acc, imp, sum]) =>
        setData({ severity: sev.data, monthly: mon.data, acceptance: acc.data, impact: imp.data.impactScore, summary: sum.data })
      )
      .catch(() => {
        toast.error("Failed to load analytics")
        setData({ severity: [], monthly: [], acceptance: [], impact: 0, summary: {} })
      })
  }, [])

  if (!data) return <Skeleton className="h-40 w-full" />
  const { summary, severity, monthly, acceptance, impact } = data

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">My analytics</h1>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
        <StatsCard title="Total reports" value={summary.totalReports ?? 0} />
        <StatsCard title="Accepted" value={summary.accepted ?? 0} subtitle={`${summary.acceptanceRate ?? 0}% acceptance`} />
        <StatsCard title="Earned" value={money(summary.totalRewards)} />
        <StatsCard title="Impact score" value={impact} />
        <StatsCard title="XP rank" value={`#${summary.rank ?? "—"}`} subtitle={`${summary.programsContributed ?? 0} programs`} />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card">
          <h2 className="mb-4 text-lg font-bold">Severity distribution</h2>
          {severity.length === 0 ? (
            <p className="py-20 text-center text-sm text-muted-foreground">No reports yet</p>
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={severity} dataKey="count" nameKey="_id" outerRadius={100} label={(d) => d._id}>
                  {severity.map((s) => <Cell key={s._id} fill={SEV[s._id] || "#3b82f6"} />)}
                </Pie>
                <Tooltip contentStyle={tip} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="card">
          <h2 className="mb-4 text-lg font-bold">Monthly activity (12 months)</h2>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
              <XAxis dataKey="_id" stroke="#94a3b8" fontSize={11} />
              <YAxis allowDecimals={false} stroke="#94a3b8" fontSize={12} />
              <Tooltip contentStyle={tip} />
              <Line type="monotone" dataKey="count" name="Reports" stroke="#22d3ee" strokeWidth={3} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <h2 className="mb-4 text-lg font-bold">Outcome overview</h2>
        <div className="flex flex-wrap gap-3">
          {acceptance.length === 0 && <p className="text-sm text-muted-foreground">No reports yet</p>}
          {acceptance.map((item) => (
            <span key={item._id} className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm capitalize">
              {item._id} — {item.count}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}
