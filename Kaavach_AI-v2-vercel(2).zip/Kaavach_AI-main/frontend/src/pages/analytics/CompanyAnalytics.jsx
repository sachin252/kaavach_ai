import { useEffect, useState } from "react"
import toast from "react-hot-toast"
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts"
import { analyticsService } from "@/services/analyticsService"
import StatsCard from "@/components/ui/StatsCard"
import { Skeleton } from "@/components/ui/skeleton"
import { money } from "@/lib/format"

export default function CompanyAnalytics() {
  const [data, setData] = useState(null)

  useEffect(() => {
    Promise.all([
      analyticsService.getCompanyReportFunnel(),
      analyticsService.getCompanyRewardSummary(),
      analyticsService.getCompanyTTR(),
      analyticsService.getCompanyProgramInsights(),
    ])
      .then(([f, r, t, i]) => setData({ funnel: f.data, rewards: r.data, ttr: t.data, insights: i.data }))
      .catch(() => {
        toast.error("Failed to load analytics")
        setData({ funnel: [], rewards: {}, ttr: {}, insights: [] })
      })
  }, [])

  if (!data) return <Skeleton className="h-40 w-full" />
  const { funnel, rewards, ttr, insights } = data

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">Company analytics</h1>
      <div className="grid gap-4 md:grid-cols-4">
        <StatsCard title="Total rewards paid" value={money(rewards.totalRewards)} />
        <StatsCard title="Average bounty" value={money(rewards.avgReward)} />
        <StatsCard title="Paid reports" value={rewards.paidReports ?? 0} />
        <StatsCard title="Avg time to resolve" value={`${(ttr.avgTTR || 0).toFixed(1)} days`} />
      </div>

      <div className="card">
        <h2 className="mb-4 text-lg font-bold">Report funnel</h2>
        {funnel.length === 0 ? (
          <p className="py-16 text-center text-sm text-muted-foreground">No reports yet</p>
        ) : (
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={funnel}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
              <XAxis dataKey="_id" stroke="#94a3b8" />
              <YAxis allowDecimals={false} stroke="#94a3b8" />
              <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #1e293b" }} />
              <Bar dataKey="count" fill="#22c55e" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="card">
        <h2 className="mb-4 text-lg font-bold">Program insights</h2>
        {insights.length === 0 && <p className="text-sm text-muted-foreground">No reports yet</p>}
        <ul className="space-y-2">
          {insights.map((p) => (
            <li key={p._id} className="flex flex-wrap justify-between gap-2 rounded-lg border border-white/10 bg-white/5 p-3">
              <span className="font-semibold">{p.title}</span>
              <span className="text-sm text-cyan-300">
                {p.reports} reports • {p.accepted} accepted • {money(p.paid)} paid
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}
