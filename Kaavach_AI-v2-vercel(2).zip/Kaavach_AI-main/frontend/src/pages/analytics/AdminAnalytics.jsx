import { useEffect, useState } from "react"
import toast from "react-hot-toast"
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts"
import { analyticsService } from "@/services/analyticsService"
import StatsCard from "@/components/ui/StatsCard"
import { Skeleton } from "@/components/ui/skeleton"

const COLORS = { pending: "#eab308", accepted: "#22c55e", rejected: "#ef4444", triaged: "#3b82f6", duplicate: "#94a3b8" }

export default function AdminAnalytics() {
  const [overview, setOverview] = useState(null)
  const [abuse, setAbuse] = useState([])

  useEffect(() => {
    Promise.all([analyticsService.getAdminOverview(), analyticsService.getAbuseDetection()])
      .then(([ov, ab]) => {
        setOverview(ov.data)
        setAbuse(ab.data || [])
      })
      .catch(() => {
        toast.error("Failed to load analytics")
        setOverview({})
      })
  }, [])

  if (!overview) return <Skeleton className="h-40 w-full" />

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-white">Platform analytics</h1>
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <StatsCard title="Total users" value={overview.users ?? 0} subtitle={`${overview.hackers ?? 0} researchers • ${overview.companies ?? 0} companies`} />
        <StatsCard title="Programs" value={overview.programs ?? 0} />
        <StatsCard title="Reports" value={overview.reports ?? 0} />
        <StatsCard title="Active researchers" value={`${overview.dau ?? 0} / ${overview.mau ?? 0}`} subtitle="Last 24h / last 30 days" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <div className="card">
          <h2 className="mb-4 text-lg font-bold">Reports by status</h2>
          {!overview.byStatus?.length ? (
            <p className="py-16 text-center text-sm text-muted-foreground">No reports yet</p>
          ) : (
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie data={overview.byStatus} dataKey="count" nameKey="_id" outerRadius={100} label={(d) => d._id}>
                  {overview.byStatus.map((s) => <Cell key={s._id} fill={COLORS[s._id] || "#06b6d4"} />)}
                </Pie>
                <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #1e293b" }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="card">
          <h2 className="mb-1 text-lg font-bold">Abuse watchlist</h2>
          <p className="mb-4 text-xs text-muted-foreground">Researchers with 5+ reports where at least half were rejected or duplicates.</p>
          {abuse.length === 0 ? (
            <p className="text-sm text-muted-foreground">No accounts flagged.</p>
          ) : (
            <table className="w-full text-sm">
              <thead className="text-left text-muted-foreground">
                <tr><th className="py-2">Researcher</th><th>Reports</th><th>Rejected/dup</th></tr>
              </thead>
              <tbody>
                {abuse.map((a) => (
                  <tr key={a._id} className="border-t border-white/10">
                    <td className="py-2">{a.name}<div className="text-xs text-muted-foreground">{a.email}</div></td>
                    <td>{a.total}</td>
                    <td className="text-red-300">{a.bad} ({Math.round(a.ratio * 100)}%)</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}
