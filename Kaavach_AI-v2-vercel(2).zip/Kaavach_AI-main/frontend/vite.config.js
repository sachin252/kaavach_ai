import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  build: {
    sourcemap: false,
    chunkSizeWarningLimit: 700,
    rollupOptions: {
      output: {
        manualChunks: {
          react: ['react', 'react-dom', 'react-router-dom', 'react-redux', '@reduxjs/toolkit'],
          charts: ['recharts'],
          motion: ['framer-motion'],
          markdown: ['react-markdown'],
        },
      },
    },
  },
  server: {
    port: 3000,
    proxy: {
      '/api': { target: process.env.API_PROXY || 'http://localhost:5000', changeOrigin: true },
      '/socket.io': { target: process.env.API_PROXY || 'http://localhost:5000', ws: true, changeOrigin: true },
    },
  },
})
