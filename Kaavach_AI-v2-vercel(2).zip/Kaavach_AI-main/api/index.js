// Vercel serverless entry: every /api/* request is handled by the Express app.
import app from '../backend/app.js';

export default app;
